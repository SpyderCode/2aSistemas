package EntradaSalida;

import javax.swing.JOptionPane;

public class MayorDeTresG {

	public static void main(String[] args) {
		String a,b,c;
		int A,B,C;
		a=JOptionPane.showInputDialog(null,"Ingrese su primer valor","Mayor de tres",JOptionPane.INFORMATION_MESSAGE);
		b=JOptionPane.showInputDialog(null,"Ingrese su segundo valor","Mayor de tres",JOptionPane.INFORMATION_MESSAGE);
		c=JOptionPane.showInputDialog(null,"Ingrese su tercer valor","Mayor de tres",JOptionPane.INFORMATION_MESSAGE);
		
		A=Integer.parseInt(a);
		B=Integer.parseInt(b);
		C=Integer.parseInt(c);
		
		if (A > B && A > C)
			JOptionPane.showMessageDialog(null,"El mayor de los tres es: "+A,"Mayor de Tres",JOptionPane.ERROR_MESSAGE);
		else if (B > A && B > C)
			JOptionPane.showMessageDialog(null,"El mayor de los tres es: "+B,"Mayor de Tres",JOptionPane.ERROR_MESSAGE);
		else
			JOptionPane.showMessageDialog(null,"El mayor de los tres es: "+C,"Mayor de Tres",JOptionPane.ERROR_MESSAGE);
	}

}
