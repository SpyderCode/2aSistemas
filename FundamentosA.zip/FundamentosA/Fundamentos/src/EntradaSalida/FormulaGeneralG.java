package EntradaSalida;

import javax.swing.JOptionPane;

public class FormulaGeneralG {

	public static void main(String[] args) {
		String A, B, C;
		float a, b, c, x1, x2;
		A = JOptionPane.showInputDialog(null, "Ingrese el valor de 'a'", "Formula General",
				JOptionPane.INFORMATION_MESSAGE);
		B = JOptionPane.showInputDialog(null, "Ingrese el valor de 'b'", "Formula General",
				JOptionPane.INFORMATION_MESSAGE);
		C = JOptionPane.showInputDialog(null, "Ingrese el valor de 'c'", "Formula General",
				JOptionPane.INFORMATION_MESSAGE);
		
		a = Float.parseFloat(A);
		b = Float.parseFloat(B);
		c = Float.parseFloat(C);
		
		x1 = (float) ((-b + Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / (2 * a));
		x2 = (float) (((-b - Math.sqrt(Math.pow(b, 2) - 4 * a * c))) / (2 * a));
		JOptionPane.showMessageDialog(null, "El valor de x1 es: " + x1 + "\n" + "El valor de x2 es: " + x2, "Resultado",
				JOptionPane.INFORMATION_MESSAGE);
	}

}
