package EntradaSalida;

import java.util.Scanner;

public class MayorDeTres {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int a, b, c;
		System.out.println("Ingrese su primer numero");
		a = in.nextInt();
		System.out.println("Ingrese su segundo numero");
		b = in.nextInt();
		System.out.println("Ingrese su tercer numero");
		c = in.nextInt();
		if (a > b && a > c)
			System.out.println("Su primer valor: " + a + " es mayor");
		else if (b > a && b > c)
			System.out.println("Su segundo valor: " + b + " es mayor");
		else
			System.out.println("Su tercer valor: " + c + " es mayor");

	}

}
