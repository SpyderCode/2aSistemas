package EntradaSalida;

import java.util.Scanner;

public class MenuAreaPerimetro {

	public static void main(String[] args) {
		menuPrincipal();

	}

	private static void menuPrincipal() {
		int opc;
		Scanner in = new Scanner(System.in);
		do {
		System.out.println("***MENU PRINCIPAL***");
		System.out.println("1.-Areas");
		System.out.println("2.-Perimetros");
		System.out.println("3.-Salir");
		System.out.println("Selecciona Opcion");
		opc=in.nextInt();
		switch (opc) {
		case 1:menuAreas();
		break;
		case 2:menuPerimetros();
		break;
		case 3:System.exit(0);
		break;
		default:System.out.println("Opcion Incorrecta");
		break;
		}
		}while(opc!=3);
		
	}

	private static void menuPerimetros() {
		int opc;
		Scanner in=new Scanner(System.in);
		do {
		System.out.println("**MENU PERIMETROS**");
		System.out.println("1.-Caudrado");
		System.out.println("2.-Triangulo");
		System.out.println("3.-Rectangulo");
		System.out.println("4.-Rombo");
		System.out.println("5.-Romboide");
		System.out.println("6.-Trapezio");
		System.out.println("7.-Circulo");
		System.out.println("8.-Poligono");
		System.out.println("9.-Regresar");
		System.out.println("Selecciona Opcion");
		opc=in.nextInt();
		switch (opc) {
		case 1:perimetroCuadrado();
		break;
		case 2:perimetroTriangulo();
		break;
		case 3:perimetroRectangulo();
		break;
		case 4:perimetroRombo();
		break;
		case 5:perimetroRomboide();
		break;
		case 6:perimetroTrapezio();
		break;
		case 7:perimetroCirculo();
		break;
		case 8:perimetroPoligono();
		break;
		case 9:menuPrincipal();
		break;
		default:System.out.println("OPCION INCORRECTA");
		}//fin del switch
		}while(opc!=9);
	}

	private static void perimetroPoligono() {
		int lado,numlado,p;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor de lados");
		lado=in.nextInt();
		System.out.println("Ingrese el numero de lados");
		numlado=in.nextInt();
		p=lado*numlado;
		System.out.println("El valor es de"+p);
		
	}

	private static void perimetroCirculo() {
		int d;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese el valor del diametro");
		d=in.nextInt();
		System.out.println("El area del circulo es de"+(d*Math.PI));
		
	}

	private static void perimetroTrapezio() {
		int base,base2,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor de la base menor");
		base=in.nextInt();
		System.out.println("Ingrese valor de la base menor");
		base2=in.nextInt();
		System.out.println("Ingrese valor de la Altura");
		altura=in.nextInt();
		System.out.println("El perimetro del romboide es: "+((base+base2+altura+altura)));
		
	}

	private static void perimetroRomboide() {
		int base,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor de la base");
		base=in.nextInt();
		System.out.println("Ingrese valor de la Altura");
		altura=in.nextInt();
		System.out.println("El perimetro del romboide es: "+((base+base+altura+altura)));
		
	}

	private static void perimetroRombo() {
		int lado;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingresa Valor del lado");
		lado=in.nextInt();
		System.out.println("El Perimetro del rombo es"+(4*lado));
		
	}

	private static void perimetroRectangulo() {
		int base,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor de la base");
		base=in.nextInt();
		System.out.println("Ingrese valor de la Altura");
		altura=in.nextInt();
		System.out.println("El perimetro del rectangulo es: "+((base+base+altura+altura)));
		
	}

	private static void perimetroTriangulo() {
		int lado1,lado2,lado3;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese lado 1");
		lado1=in.nextInt();
		System.out.println("Ingrese lado 2");
		lado2=in.nextInt();
		System.out.println("Ingrese lado 3");
		lado3=in.nextInt();
		System.out.println("El perimetro del triangulo es: "+(lado1+lado2+lado3));
		
	}

	private static void perimetroCuadrado() {
		int lado;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingresa Valor del lado");
		lado=in.nextInt();
		System.out.println("El Perimetro del cuadrado es"+(4*lado));
	}

	private static void menuAreas() {
		int opc;
		Scanner in=new Scanner(System.in);
		do {
		System.out.println("**MENU PERIMETROS**");
		System.out.println("1.-Caudrado");
		System.out.println("2.-Triangulo");
		System.out.println("3.-Rectangulo");
		System.out.println("4.-Rombo");
		System.out.println("5.-Romboide");
		System.out.println("6.-Trapezio");
		System.out.println("7.-Circulo");
		System.out.println("8.-Poligono");
		System.out.println("9.-Regresar");
		System.out.println("Selecciona Opcion");
		opc=in.nextInt();
		switch (opc) {
		case 1:areaCuadrado();
		break;
		case 2:areaTriangulo();
		break;
		case 3:areaRectangulo();
		break;
		case 4:areaRombo();
		break;
		case 5:areaRomboide();
		break;
		case 6:areaTrapezio();
		break;
		case 7:areaCirculo();
		break;
		case 8:areaPoligono();
		break;
		case 9:menuPrincipal();
		break;
		default:System.out.println("OPCION INCORRECTA");
		}//fin del switch
		}while(opc !=9);
	}

	private static void areaPoligono() {
		int lado,numlado,ap,p;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor de lados");
		lado=in.nextInt();
		System.out.println("Ingrese el numero de lados");
		numlado=in.nextInt();
		p=lado*numlado;
		System.out.println("Ingrese el apotema");
		ap=in.nextInt();
		System.out.println("El area es de: "+(ap*p/2));
		
	}

	private static void areaCirculo() {
		int radio;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingresa el radio");
		radio=in.nextInt();
		System.out.println("El area es de"+(Math.pow(radio, 2)*Math.PI));
	}

	private static void areaTrapezio() {
		int base1,base2,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingresa la base mayor");
		base1=in.nextInt();
		System.out.println("Ingresa la base menor");
		base2=in.nextInt();
		System.out.println("Ingresa la altura");
		altura=in.nextInt();
		System.out.println("El area del trapezio es: "+(altura*base1*base2/2));
		
	}

	private static void areaRomboide() {
		int base,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese la base");
		base=in.nextInt();
		System.out.println("Ingrese la altura");
		altura=in.nextInt();
		System.out.println("El area del Romboide es: "+(altura*base));
		
	}

	private static void areaRombo() {
		int diagM,diagme;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor del diagonal mayor");
		diagM=in.nextInt();
		System.out.println("Ingrese valor del diagonal menor");
		diagme=in.nextInt();
		System.out.println("El area del rombo es"+(diagM*diagme));
		
	}

	private static void areaRectangulo() {
		int base,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese la base");
		base=in.nextInt();
		System.out.println("Ingrese la altura");
		altura=in.nextInt();
		System.out.println("El area del Rectangulo es: "+(altura*base));
	}

	private static void areaTriangulo() {
		int base,altura;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor de la base");
		base=in.nextInt();
		System.out.println("Ingrese valor de la Altura");
		altura=in.nextInt();
		System.out.println("El area del triangulo es: "+((base*altura)/2));
	}

	private static void areaCuadrado() {
		int lado;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese valor del Lado");
		lado=in.nextInt();
		System.out.println("El area es"+(lado*lado));
		
	}

}
