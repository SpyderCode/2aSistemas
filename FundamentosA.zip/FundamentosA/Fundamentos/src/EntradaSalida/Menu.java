package EntradaSalida;

import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int opc;
		do{
		System.out.println("~~~MENU~~~");
		System.out.println("1.-Primer Saludo ");
		System.out.println("2.-Segundo Saludo");
		System.out.println("3.-Tercer Saludo ");
		System.out.println("4.- Salir ");
		System.out.println("Selecciona Opcion");
		opc=in.nextInt();
		switch(opc){
			case 1:System.out.println("Buenos Dias");
				break;
			case 2: System.out.println("Buenas Tardes");
				break;
			case 3:System.out.println("Buenas Noches");
				break;
			case 4:System.exit(0); 
				break;
			default:System.out.println("ERROR");
				break;
		}//fin del switch
	}while(opc !=4);
	}//fin del main

}//fin del la class
