package EntradaSalida;
import java.util.Scanner;
public class AreaCirculo {
	public static void main(String[] args) {
		//Pi*radio*radio
		Scanner in=new Scanner(System.in);
		float radio,area;
		System.out.println("~~Area de un Circulo~~");
		System.out.println("Ingresa Valor del radio");
		radio=in.nextFloat();
		area=(float) (Math.PI*Math.pow(radio,2));
		System.out.println("Area del Circulo="+area);
		

	}

}
