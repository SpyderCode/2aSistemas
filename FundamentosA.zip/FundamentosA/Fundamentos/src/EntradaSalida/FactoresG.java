package EntradaSalida;

import javax.swing.JOptionPane;

public class FactoresG {

	public static void main(String[] args) {
		int x,y,num;
		String NUM;
		int factores[];
		NUM=JOptionPane.showInputDialog(null,"Ingrese el numero","Factores",JOptionPane.DEFAULT_OPTION);
		num=Integer.parseInt(NUM);
		for(x=1;x<=num;x++)
			for(y=1;y<=num;y++)
				if(num%x==0&&num%y==0&&x*y==num)
					JOptionPane.showMessageDialog(null, x+"X"+y+"="+num);
					
	}

}
