package EntradaSalida;

import java.util.Scanner;

public class Factores {

	public static void main(String[] args) {
		int i,x,y,num;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese el numero");
		num=in.nextInt();
		if (num==69)
			System.out.println("Tu y yo 7u7");
		
		for(x=0;x<=num;x++) {
			for(y=0;y<=num;y++) {
				if(x*y==num)
					System.out.println(x+" X "+y+" = "+num);
			}//fin de for menor
		
		}//fin de for mayor
		System.out.println("\nTerminado");
	}

}
