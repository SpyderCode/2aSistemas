package EntradaSalida;

import javax.swing.JOptionPane;

public class AreaCirculoG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Radio;
		float radio, area;
		Radio = JOptionPane.showInputDialog(null, "Ingresa Valor del radio", "Area del Circulo",JOptionPane.INFORMATION_MESSAGE);
		radio = Float.parseFloat(Radio);
		area = (float) (Math.PI * Math.pow(radio, 2));
		JOptionPane.showMessageDialog(null, "Area= " + area, "Resultado del Area del Circulo",JOptionPane.CANCEL_OPTION);
		JOptionPane.showMessageDialog(null, (2*Math.PI*radio),"Perimetro del Circulo",JOptionPane.ERROR_MESSAGE);

	}

}
