package EntradaSalida;

import java.util.Scanner;

public class FormulaGeneral {

	public static void main(String[] args) {
		java.util.Scanner in = new Scanner(System.in);
		float a,b,c,x1,x2;
		System.out.println("Ingrese el valor de a");
		a=in.nextFloat();
		System.out.println("Ingrese el valor de b");
		b=in.nextFloat();
		System.out.println("Ingrese el valor de c");
		c=in.nextFloat();
		x1=(float) ((-b+Math.sqrt(Math.pow(b,2)-4*a*c))/(2*a));
		x2=(float) (((-b-Math.sqrt(Math.pow(b,2)-4*a*c)))/(2*a));
		System.out.println("X1="+x1);
		System.out.println("X2="+x2);
	}
}
