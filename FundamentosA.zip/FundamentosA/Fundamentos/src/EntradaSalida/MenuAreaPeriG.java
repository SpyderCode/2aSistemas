package EntradaSalida;

import javax.swing.JOptionPane;

public class MenuAreaPeriG {

	public static void main(String[] args) {
		menu();

	}

	private static void menu() {
		String opc;
		int Opc;
		do {
		opc=JOptionPane.showInputDialog(null,"1.-Areas\n2.-Perimetros\n3.-Salir","Menu Principal",JOptionPane.INFORMATION_MESSAGE);
		Opc=Integer.parseInt(opc);
		switch (Opc) {
		case 1:menuAreas();
			break;
		case 2:menuPerimetros();
			break;
		case 3:System.exit(0);
			break;
		default:JOptionPane.showMessageDialog(null, "Opcion Incorrecta","ERROR",JOptionPane.ERROR_MESSAGE);
			break;
		
		}//Fin del switch
		}while(Opc!=3);
	}

	private static void menuPerimetros() {
		String opc;
		int Opc;
		do {
		opc=JOptionPane.showInputDialog(null,"1.-Caudrado\n2.-Triangulo\n3.-Rectangulo\n"
				+ "4.-Rombo\n5.-Romboide\n6.-Trapezio\n7.-Circulo\n8.-Poligono\n"
				+ "9.-Regresar","Menu Perimetros",JOptionPane.INFORMATION_MESSAGE);
		
		Opc=Integer.parseInt(opc);
		switch (Opc) {
		case 1:perimetroCuadrado();
			break;
		case 2:perimetroTriangulo();
			break;
		case 3:perimetroRectangulo();
			break;
		case 4:perimetroRombo();
			break;
		case 5:perimetroRomboide();
			break;
		case 6:perimetroTrapezio();
			break;
		case 7:perimetroCirculo();
			break;
		case 8:perimetroPoligono();
			break;
		case 9:menu();
			break;
		default:JOptionPane.showMessageDialog(null, "Opcion Incorrecta","ERROR",JOptionPane.ERROR_MESSAGE);
			break;
		}//fin del switch
		}while(Opc!=9);
	}

	private static void perimetroPoligono() {
		int lado,Num,peri;
		String L,num;
		L=JOptionPane.showInputDialog(null,"Ingrese el valor de los lados","Area Poligono",JOptionPane.INFORMATION_MESSAGE);
		num=JOptionPane.showInputDialog(null,"Cuantos lados son?","Area Poligono",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(L);
		Num=Integer.parseInt(num);
		peri=Num*lado;
		JOptionPane.showMessageDialog(null, "El area es de "+(peri),"Resultado",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void perimetroCirculo() {
		int radio;
		String R;
		R=JOptionPane.showInputDialog(null,"Ingrese el valor del radio","Perimetro Circulo",JOptionPane.INFORMATION_MESSAGE);
		radio=Integer.parseInt(R);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(2*radio*Math.PI),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void perimetroTrapezio() {
		int lado,base,base2;
		String Lado,Base,Base2;
		Lado=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Perimetro Trapezoide",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(Lado);
		Base=JOptionPane.showInputDialog(null,"Ingrese el valor de la base mayor","Perimetro Trapezoide",JOptionPane.INFORMATION_MESSAGE);
		base=Integer.parseInt(Base);
		Base2=JOptionPane.showInputDialog(null,"Ingrese el valor de la base menor","Perimetro Trapezoide",JOptionPane.INFORMATION_MESSAGE);
		base2=Integer.parseInt(Base2);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(lado+lado+base+base2),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
		
	}

	private static void perimetroRomboide() {
		int lado,base;
		String Lado,Base;
		Lado=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Perimetro Romboide",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(Lado);
		Base=JOptionPane.showInputDialog(null,"Ingrese el valor de la base","Perimetro Romboide",JOptionPane.INFORMATION_MESSAGE);
		base=Integer.parseInt(Base);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(lado+lado+base+base),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
		
	}

	private static void perimetroRombo() {
		int lado;
		String Lado;
		Lado=JOptionPane.showInputDialog(null,"Ingrese el valor del lado","Perimetro Rombo",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(Lado);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(lado+lado+lado+lado),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
		
	}

	private static void perimetroRectangulo() {
		int lado,base;
		String Lado,Base;
		Lado=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Perimetro Rectangulo",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(Lado);
		Base=JOptionPane.showInputDialog(null,"Ingrese el valor de la base","Perimetro Rectangulo",JOptionPane.INFORMATION_MESSAGE);
		base=Integer.parseInt(Base);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(lado+lado+base+base),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void perimetroTriangulo() {
		int lado1,lado2,lado3;
		String Lado1,Lado2,Lado3;
		Lado1=JOptionPane.showInputDialog(null,"Ingrese el valor del lado 1","Perimetro Triangulo",JOptionPane.INFORMATION_MESSAGE);
		lado1=Integer.parseInt(Lado1);
		Lado2=JOptionPane.showInputDialog(null,"Ingrese el valor del lado 2","Perimetro Triangulo",JOptionPane.INFORMATION_MESSAGE);
		lado2=Integer.parseInt(Lado2);
		Lado3=JOptionPane.showInputDialog(null,"Ingrese el valor del lado 3","Perimetro Triangulo",JOptionPane.INFORMATION_MESSAGE);
		lado3=Integer.parseInt(Lado3);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(lado1+lado2+lado3),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void perimetroCuadrado() {
		int lado;
		String Lado;
		Lado=JOptionPane.showInputDialog(null,"Ingrese el valor del lado","Perimetro Cuadrado",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(Lado);
		JOptionPane.showMessageDialog(null, "El perimetro es de "+(lado+lado+lado+lado),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void menuAreas() {
		String opc;
		int Opc;
		do {
		opc=JOptionPane.showInputDialog(null,"1.-Caudrado\n2.-Triangulo\n3.-Rectangulo"
				+ "\n4.-Rombo\n5.-Romboide\n6.-Trapezio\n7.-Circulo\n8.-Poligono"
				+ "\n9.-Regresar","Menu Areas",JOptionPane.INFORMATION_MESSAGE);
		
		Opc=Integer.parseInt(opc);
		switch (Opc) {
		case 1:areaCuadrado();
		break;
		case 2:areaTriangulo();
		break;
		case 3:areaRectangulo();
		break;
		case 4:areaRombo();
		break;
		case 5:areaRomboide();
		break;
		case 6:areaTrapezio();
		break;
		case 7:areaCirculo();
		break;
		case 8:areaPoligono();
		break;
		case 9:menu();
		break;
		default:JOptionPane.showMessageDialog(null, "Opcion Incorrecta","ERROR",JOptionPane.ERROR_MESSAGE);
			break;
		}//fin del switch
		}while(Opc!=9);
		
	}

	private static void areaPoligono() {
		int lado,Num,ap,peri;
		String L,AP,num;
		L=JOptionPane.showInputDialog(null,"Ingrese el valor de los lados","Area Poligono",JOptionPane.INFORMATION_MESSAGE);
		num=JOptionPane.showInputDialog(null,"Cuantos lados son?","Area Poligono",JOptionPane.INFORMATION_MESSAGE);
		AP=JOptionPane.showInputDialog(null,"Ingrese el valor del Apotema","Area Poligono",JOptionPane.INFORMATION_MESSAGE);
		ap=Integer.parseInt(AP);
		lado=Integer.parseInt(L);
		Num=Integer.parseInt(num);
		peri=Num*lado;
		JOptionPane.showMessageDialog(null, "El area es de "+(peri*ap/2),"Resultado",JOptionPane.INFORMATION_MESSAGE);
		
		
	}

	private static void areaCirculo() {
		int radio;
		String R;
		R=JOptionPane.showInputDialog(null,"Ingrese el valor del radio","Area Circulo",JOptionPane.INFORMATION_MESSAGE);
		radio=Integer.parseInt(R);
		JOptionPane.showMessageDialog(null, "El area es de "+(Math.pow(radio, 2)*Math.PI),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
	}

	private static void areaTrapezio() {
		int  base1,base2,alt1;
		String Base1,Base2,Alt1;
		Base1=JOptionPane.showInputDialog(null,"Ingrese el valor de la base menor","Area Trapecio",JOptionPane.INFORMATION_MESSAGE);
		Base2=JOptionPane.showInputDialog(null,"Ingrese el valor de la base mayor","Area Trapecio",JOptionPane.INFORMATION_MESSAGE);
		Alt1=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Area Trapecio",JOptionPane.INFORMATION_MESSAGE);
		base2=Integer.parseInt(Base2);
		base1=Integer.parseInt(Base1);
		alt1=Integer.parseInt(Alt1);
		JOptionPane.showMessageDialog(null, "El area es de "+(base1*alt1*base2/2),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void areaRomboide() {
		int  base,alt;
		String Base,Alt;
		Base=JOptionPane.showInputDialog(null,"Ingrese el valor de la base","Area Romboide",JOptionPane.INFORMATION_MESSAGE);
		Alt=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Area Romboide",JOptionPane.INFORMATION_MESSAGE);
		base=Integer.parseInt(Base);
		alt=Integer.parseInt(Alt);
		JOptionPane.showMessageDialog(null, "El area es de "+(base*alt),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void areaRombo() {
		int  D,d;
		String Diag,diag;
		Diag=JOptionPane.showInputDialog(null,"Ingrese el valor del diagonal mayor","Area Rombo",JOptionPane.INFORMATION_MESSAGE);
		diag=JOptionPane.showInputDialog(null,"Ingrese el valor del diagonal menor","Area Rombo",JOptionPane.INFORMATION_MESSAGE);
		D=Integer.parseInt(Diag);
		d=Integer.parseInt(diag);
		JOptionPane.showMessageDialog(null, "El area es de "+(D*d),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void areaRectangulo() {
		int  base,alt;
		String Base,Alt;
		Base=JOptionPane.showInputDialog(null,"Ingrese el valor de la base","Area Rectangulo",JOptionPane.INFORMATION_MESSAGE);
		Alt=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Area Rectangulo",JOptionPane.INFORMATION_MESSAGE);
		base=Integer.parseInt(Base);
		alt=Integer.parseInt(Alt);
		JOptionPane.showMessageDialog(null, "El area es de "+(base*alt),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static void areaTriangulo() {
		int  base,alt;
		String Base,Alt;
		Base=JOptionPane.showInputDialog(null,"Ingrese el valor de la base","Area Triangulo",JOptionPane.INFORMATION_MESSAGE);
		Alt=JOptionPane.showInputDialog(null,"Ingrese el valor de la altura","Area Triangulo",JOptionPane.INFORMATION_MESSAGE);
		base=Integer.parseInt(Base);
		alt=Integer.parseInt(Alt);
		JOptionPane.showMessageDialog(null, "El area es de "+(base*alt/2),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
	}

	private static void areaCuadrado() {
		int lado;
		String Lado;
		Lado=JOptionPane.showInputDialog(null,"Ingrese el valor del lado","Area Cuadrado",JOptionPane.INFORMATION_MESSAGE);
		lado=Integer.parseInt(Lado);
		JOptionPane.showMessageDialog(null, "El area es de "+(lado*lado),"Respuesta",JOptionPane.INFORMATION_MESSAGE);
		
	}

}
