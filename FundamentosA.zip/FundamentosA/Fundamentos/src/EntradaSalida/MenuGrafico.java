package EntradaSalida;

import javax.swing.JOptionPane;

public class MenuGrafico {

	public static void main(String[] args) {
		String OPC;
		int opcion;
		do {
		OPC = JOptionPane.showInputDialog(null, "1.-Primer Saludo \n" + "2.-Segundo Saludo\n" + "3.-Tercer Saludo\n",
				"Menu Principal", JOptionPane.INFORMATION_MESSAGE);
		opcion = Integer.parseInt(OPC);
		switch (opcion) {
		case 1:
			JOptionPane.showMessageDialog(null, "Buenos Dias", "Primer mensaje", JOptionPane.INFORMATION_MESSAGE);
			break;
		case 2:
			JOptionPane.showMessageDialog(null, "Buenas Tardes", "Segundo Mensaje", JOptionPane.INFORMATION_MESSAGE);
			break;
		case 3:
			JOptionPane.showMessageDialog(null, "Buenas Noches", "Tercer Mensaje", JOptionPane.QUESTION_MESSAGE);
			break;
		default:
			JOptionPane.showMessageDialog(null, "ERROR", "ERROR", JOptionPane.ERROR_MESSAGE);
			break;

		}//fin del switch
		}while(opcion!=4);
		
	}

}
