package EntradaSalida;

import javax.swing.JOptionPane;

public class ERROR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double x;
		x=(double) (.2+.1);
		System.out.println(x);
		}
			
	

}
