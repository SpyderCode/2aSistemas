package Examen2;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Examen {

	public static void main(String[] args) {
		menu();

	}

	private static void menu() {
		int opc;
		Scanner in=new Scanner(System.in);
		do {
		System.out.println("\nMENU");
		System.out.println("1.-Problema 1\n2.-Probelma 2\n3.-Problema 3\n4.-Problema 4\n5.-Problema 5\n6.-Problema 6\n7.-Exit\nElige un problema");
		opc=in.nextInt();
		switch (opc) {
		case 1:System.out.println("Ponga 100 profe");
			break;
		case 2:multiplosDeDos();
			break;
		case 3:intercalado();
			break;
		case 4:operaciones();
			break;
		case 5:ecuacionRara();
			break;
		case 6:Busqueda();
			break;
		case 7:System.exit(0);
		default:System.out.println("Opcion incorrecta");
			break;
		}}while(opc!=7);
		
	}

	private static void Busqueda() {//problema 6
		Random na= new Random();
		int arreglo[]=new int[20];
		int num;
		Scanner in=new Scanner(System.in);
		
		for(int i=0;i<arreglo.length;i++)
			arreglo[i]=na.nextInt(50)+1;
		for(int i=0;i<arreglo.length;i++)
			System.out.print(arreglo[i]+"\t");
		
		System.out.println("\nIngrese el numero");
		num=in.nextInt();
		for(int i=0;i<arreglo.length;i++) {
			if(num==arreglo[i])
				System.out.println("Numero "+num+" encontrado en la posicion "+i);
			if(i==arreglo.length-1)
				System.out.println("Terminado!");}
		
	}

	private static void ecuacionRara() {//problema5
		Random nr=new Random();
		Integer[] x=new Integer[10];
		Integer[] y=new Integer[10];
		int i,a,b,c,z;//resultados
		int sumxy = 0,sumx2y2=0,sumx_y=0,sumxy2=0,sumx2y=0,sumx_y2=0;//sumatorias
		for(i=0;i<x.length;i++) {
			x[i]=nr.nextInt(20)+1;
			y[i]=nr.nextInt(20)+1;
			}
		System.out.println("\nArreglo x\n");
		for(i=0;i<x.length;i++)
			System.out.print(x[i]+"\t");
		
		System.out.println("\nArreglo y\n");
		for(i=0;i<x.length;i++)
			System.out.print(y[i]+"\t");
		
		for(i=0;i<y.length;i++) {//sumatorias
			sumxy+=(x[i]+y[i]);
			sumx2y2+=(Math.pow(x[i], 2)*Math.pow(y[i], 2));
			sumx_y+=x[i]-y[i];
			sumxy2+=x[i]*Math.pow(y[i], 2);
			sumx2y+=Math.pow(x[i], 2)*y[i];
			sumx_y2+=x[i]-Math.pow(y[i], 2);
			}
		a=sumxy+sumx2y2+sumx_y;
		b=sumxy2+sumx2y-a;
		c=sumx_y2+a-b;
		z=a+b-c;
		System.out.println("\nEl resultado de z es: "+z);
		
	}

	private static void operaciones() {//problema4
		Random nr=new Random();
		Integer[] array=new Integer[10];
		Integer[] array2=new Integer[10];
		int i;
		for(i=0;i<array.length;i++) {
			array[i]=nr.nextInt(10)+1;
			array2[i]=nr.nextInt(10)+1;
			}	
		System.out.println("\nArreglo1");
		for(i=0;i<array.length;i++)
			System.out.print(array[i]+"\t");
		System.out.println("\nArreglo2");
		for(i=0;i<array2.length;i++)
			System.out.print(array2[i]+"\t");
		System.out.println("\nSuma");
		for(i=0;i<array.length;i++)
			System.out.print((array[i]+array2[i])+"\t");
		System.out.println("\nResta");
		for(i=0;i<array.length;i++)
			System.out.print((array[i]-array2[i])+"\t");
		System.out.println("\nMultiplicacion");
		for(i=0;i<array.length;i++)
			System.out.print((array[i]*array2[i])+"\t");
			
		
	}

	private static void intercalado() {//problema3
		Random nr=new Random();
		Integer[] array=new Integer[10];
		Integer[] array2=new Integer[10];
		Integer[] intercalado=new Integer[20];
		int i,j,x;
		for(i=0;i<array.length;i++) {
			array[i]=nr.nextInt(20)+1;
			array2[i]=nr.nextInt(20)+1;
		}//fin de for
		System.out.println("\nArray 1");
		for (i = 0; i < array.length; i++)
			System.out.print(array[i] + "\t");
		System.out.println("\nArray 2");

		for (i = 0; i < array2.length; i++)
			System.out.print(array2[i] + "\t");
		System.out.println();
		
		for (i=0,j=0,x=1;i<array.length;i++,j+=2,x+=2) {
			intercalado[j]=array[i];
			intercalado[x]=array2[i];
			}
		System.out.println("\nIntercalado");
		for (i = 0; i < intercalado.length; i++)
			System.out.print(intercalado[i] + "\t");
	}

	private static void multiplosDeDos() {//problema 2
		Random nr=new Random();
		Integer[] array=new Integer[20];
		int i=0,suma=0;
		for(i=0;i<array.length;i++)
			array[i]=nr.nextInt(100)+1;
		System.out.println("Arreglo\n");
		for(i=0;i<array.length;i++)
			System.out.print(array[i]+"\t");
		for(i=0;i<array.length;i++) {
			if (array[i]%2==0)
				suma+=1;
		}//fin de for suma
		System.out.println("\n\nSe encontro "+suma+" multiplos de 2");
		
	}



}
