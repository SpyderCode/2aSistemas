
public class carlos {

	import java.util.Arrays;
	import java.util.Random;
	import java.util.Scanner;

	public class exa {

		public static void main(String[] args) {
			menu();

		}

		private static void menu() {
			int opc;
			Scanner in=new Scanner(System.in);
			do {
			System.out.println("\nMENU");
			System.out.println("1\n2.-ejercicio 2\n3.-ejercicio 3\n4.-ejercicio 4\n5.-ejercicio 5\n6.-ejercicio 6\n7.-Exit\nselecciona un ejercicio");
			opc=in.nextInt();
			switch (opc) {
			case 1:orden();
				break;
			case 2:multiplosDeDos();
				break;
			case 3:intercale();
				break;
			case 4:operaciones();
				break;
			case 5:ecuacionRara();
				break;
			case 6:Busqueda();
				break;
			case 7:System.exit(0);
			default:System.out.println("Opcion incorrecta");
				break;
			}}while(opc!=7);
			
		}

		private static void Busqueda() {
			Random na= new Random();
			int arreglo[]=new int[20];
			int num;
			Scanner in=new Scanner(System.in);
			
			
			for(int i=0;i<arreglo.length;i++)
				arreglo[i]=na.nextInt(50)+1;
			for(int i=0;i<arreglo.length;i++)
				System.out.print(arreglo[i]+"\t");
			
			System.out.println("\nIngrese el numero");
			num=in.nextInt();
			for(int i=0;i<arreglo.length;i++) {
				if(num==arreglo[i])
					System.out.println("Numero "+num+" encontrado en la posicion "+i);
				if(i==arreglo.length-1)
					System.out.println("Terminado!");}
			
		}

		private static void ecuacionRara() {
			Random nr=new Random();
			Integer[] x=new Integer[10];
			Integer[] y=new Integer[10];
			int i,a,b,c,z;
			int sumxy = 0,sumx2y2=0,sumx=0,sumy=0,sumxy2=0,sumx2y=0,sumy2=0;//sumatorias
			for(i=0;i<x.length;i++) {
				x[i]=nr.nextInt(20)+1;
				y[i]=nr.nextInt(20)+1;
				}
			System.out.println("\nArreglo x\n");
			for(i=0;i<x.length;i++)
				System.out.print(x[i]+"\t");
			
			System.out.println("\nArreglo y\n");
			for(i=0;i<x.length;i++)
				System.out.print(y[i]+"\t");
			
			for(i=0;i<y.length;i++) {
				sumxy+=x[i]*y[i];
				sumx2y2+=(Math.pow(x[i], 2)*Math.pow(y[i], 2));
				sumx+=x[i];
				sumy+=y[i];
				sumxy2+=x[i]*Math.pow(y[i], 2);
				sumx2y+=y[i]*Math.pow(x[i], 2);
				sumy2+=Math.pow(y[i], 2);
				}
			a=sumxy+sumx2y2+sumx-sumy;
			b=sumxy2+sumx2y-a;
			c=sumx-sumy2+a-b;
			z=a+b-c;
			System.out.println("\nEl resultado de z es: "+z);
			
		}

		private static void operaciones() {
			Random nr=new Random();
			Integer[] array=new Integer[10];
			Integer[] array2=new Integer[10];
			int intercalado[] = new int[20];
			int i, x, j;
			for(i=0;i<array.length;i++) {
				array[i]=nr.nextInt(20)+1;
				array2[i]=nr.nextInt(20)+1;
				}	
			System.out.println("Arreglo1\tArreglo2\tSuma\tResta\tMult\n");
			for(i=0;i<array.length;i++)
				System.out.println(array[i]+"\t\t"+array2[i]+"\t\t"+(array[i]+array2[i])+"\t"+(array[i]-array2[i])+"\t"+(array[i]*array2[i])+"\n");
						
			
		}

		private static void intercale() {
			Random nr=new Random();
			Integer[] array=new Integer[10];
			Integer[] array2=new Integer[10];
			Integer[] intercalado=new Integer[20];
			int i,j,x;
			for(i=0;i<array.length;i++) {
				array[i]=nr.nextInt(10)+1;
				array2[i]=nr.nextInt(10)+1;
			}
			for (i = 0; i < array.length; i++)
				System.out.print(array[i] + "\t");
			System.out.println();

			for (i = 0; i < array2.length; i++)
				System.out.print(array2[i] + "\t");
			System.out.println();
			
			for (i=0,j=0,x=1;i<array.length;i++,j+=2,x+=2) {
				intercalado[j]=array[i];
				intercalado[x]=array2[i];
				}
			for (i = 0; i < intercalado.length; i++)
				System.out.print(intercalado[i] + "\t");
		}

		private static void multiplosDeDos() {
			Random nr=new Random();
			Integer[] array=new Integer[20];
			int i=0,suma=0;
			for(i=0;i<array.length;i++)
				array[i]=nr.nextInt(100)+1;
			System.out.println("Arreglo\n");
			for(i=0;i<array.length;i++)
				System.out.print(array[i]+"\t");
			for(i=0;i<array.length;i++) {
				if (array[i]%2==0)
					suma+=1;
			}
			System.out.println("\n\nHay "+suma+" multiplos de 2");
			
		}

		private static void orden() {
			Random nr=new Random();
			Integer[] array=new Integer[10];
			int i=0;
			for(i=0;i<array.length;i++)
				array[i]=nr.nextInt(10)+1;
			for(i=0;i<array.length;i++)
				System.out.print(array[i]+"\t");
				
			Integer[] arraysort=Arrays.copyOf(array, 10);
			Arrays.sort(arraysort);
			System.out.println("\nOrdenado\n");
			for(i=0;i<arraysort.length;i++)
				System.out.print(arraysort[i]+"\t");
			System.out.println("\nDescendentes\n");
			for(i=array.length-1;i>=0;i--)
				System.out.print(arraysort[i]+"\t");
			
		}

	}
