package Practicas;

public class Practica_1 {

	public static void main(String[] args) {
		for (int i=1; i<=10; i++) {
			if (i % 2 != 0)
			continue; //el n�mero es impar, se interrumpe la iteraci�n
			System.out.println("N�meros pares: " + i);

		}
	}
}
