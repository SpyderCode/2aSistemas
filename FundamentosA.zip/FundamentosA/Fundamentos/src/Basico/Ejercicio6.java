package Basico;

public class Ejercicio6 {

	public static void main(String[] args) {
		int a=10,b=7,c=12;
		if (a<b && a<c)
			System.out.println(a+" es menor");
		else if(b<a && b<c)
			System.out.println(b+" es menor");
		else
			System.out.println(c+" es menor");

	}

}
