package Basico;

public class GradosCent {

	public static void main(String[] args) {
		final double PI=3.1416;
		double gradosFarh=58,gradosCent;
		gradosCent=((gradosFarh-32)*5)/9;
		System.out.println("La temperatura actual "+"en Zacatecas es de "+ gradosCent+"\nGrados Centigrados");
		//C=((F-32)*5)/9;

	}

}
