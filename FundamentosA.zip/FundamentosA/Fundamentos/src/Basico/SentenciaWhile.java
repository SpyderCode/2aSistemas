package Basico;

public class SentenciaWhile {

	public static void main(String[] args) {
		int i = 0;// Inicializacion
		System.out.println("Numeros");
		while (i <= 10) {// condicion
			System.out.print(i + "\t");
			i++;// incremento
		}//Fin del while
		
		System.out.println("\nNumeros pares");
		i = 0;
		while (i <= 20) {
			System.out.print(i + "\t");
			i += 2;
		}//Fin del while
		
		System.out.println("\nNumeros Impares");
		i = 1;
		while (i <= 21) {
			System.out.print(i + "\t");
			i += 2;
		}//Fin del while
	}
}
