package Basico;

public class GradosFarh {

	public static void main(String[] args) {
		double gradosFarh,gradosCent=14;
		gradosFarh=(gradosCent*1.8)+32;
		System.out.println("La temperatura de Villanueva es de "+gradosFarh+" grados Fahrenheit");
		//F=(C*1.8)+32

	}

}
