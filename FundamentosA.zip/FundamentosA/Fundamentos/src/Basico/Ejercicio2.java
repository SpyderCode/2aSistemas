package Basico;

public class Ejercicio2 {

	public static void main(String[] args) {
		double examen=70;
		int programas_entregadas=8;
		if (examen>=70 && programas_entregadas>=8)
			System.out.println("Aprobado");
		else
			System.out.println("Reprobado");

	}

}
