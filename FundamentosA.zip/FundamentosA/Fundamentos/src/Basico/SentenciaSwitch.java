package Basico;

public class SentenciaSwitch {

	public static void main(String[] args) {
		int dia=7;
		System.out.println("Dia de la Semana");
		switch(dia) {
		case 1: System.out.println("El dia "+dia+" corresponde a Lunes");
		break;
		case 2: System.out.println("El dia "+dia+" corresponde a Martes");
		break;
		case 3: System.out.println("El dia "+dia+" corresponde a Miercoles");
		break;
		case 4: System.out.println("El dia "+dia+" corresponde a Jueves");
		break;
		case 5: System.out.println("El dia "+dia+" corresponde a Viernes");
		break;
		case 6: System.out.println("El dia "+dia+" corresponde a Sabado");
		break;
		case 7: System.out.println("El dia "+dia+" corresponde a Domingo");
		break;
		default:System.out.println("ERROR");
		break;
		}

	}

}
