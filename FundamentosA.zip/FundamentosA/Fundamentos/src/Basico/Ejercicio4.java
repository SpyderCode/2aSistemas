package Basico;

public class Ejercicio4 {

	public static void main(String[] args) {
		int temp=120,presion=100;
		if (presion>200 || temp>100)
			System.out.println("Alarma");
		else
			System.out.println("Normal");

	}

}
