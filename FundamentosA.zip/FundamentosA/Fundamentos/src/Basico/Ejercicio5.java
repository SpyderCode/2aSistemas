package Basico;

public class Ejercicio5 {

	public static void main(String[] args) {
		if(false)
			System.out.println("false es equivalente a verdadero\n");
		else
			System.out.println("false es equivalente a falso \n");

	}

}
