package Basico;

public class TablaMultiplicar {

	public static void main(String[] args) {
		int x;
		for (x=1; x <= 10; x++) {
			System.out.println("TABLA DEL " + x);
			for (int i = 1; i <= 10; i++)
				System.out.println(x + " X " + i + " = " + x * i + "\n");
				// Fin del for interno
		} // fin del for externo
	}

}
