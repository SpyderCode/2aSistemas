package Basico;

public class Menu {

	public static void main(String[] args) {
		int opc = 6;
		System.out.println("~~MENU~~");
		System.out.println("1.-Altas");
		System.out.println("2.-Bajas");
		System.out.println("3.-Cambios");
		System.out.println("4.-Consultas");
		System.out.println("5.-Reportes");
		System.out.println("6.-Salir");

		switch (opc) {
		case 1:
			System.out.println("LAS ALTAS");
			break;
		case 2:
			System.out.println("las bajas");
			break;
		case 3:
			System.out.println("LoS cAmBiOs");
			break;
		case 4:
			System.out.println("consultas");
			break;
		case 5:
			System.out.println("Reportes dun dun duuuuuuun");
			break;
		case 6:
			System.out.println("Salir tan rapido? :c");
			System.exit(0);
			break;
		default:
			System.out.println("ERROR");
			break;

		}

	}

}
