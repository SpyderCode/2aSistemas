package Basico;

public class Ejercicio1 {

	public static void main(String[] args) {
		int puntuacion=100;
		if (puntuacion>100)
			System.out.println("Alto");
		else if(puntuacion<=100)
			System.out.println("Bajo");
			

	}

}
