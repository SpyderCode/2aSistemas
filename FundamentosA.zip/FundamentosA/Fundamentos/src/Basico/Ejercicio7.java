package Basico;

public class Ejercicio7 {

	public static void main(String[] args) {
		int a=10,b=12,c=11,d=20;
		if (a<b && a<c && a<d)
			System.out.println(a+" es menor");
		else if(b<a && b<c && b<d)
			System.out.println(b+" es menor");
		else if(d<a && b<c && d<b)
			System.out.println(d+" es menor");
		else
			System.out.println(c+" es menor");

	}

}
