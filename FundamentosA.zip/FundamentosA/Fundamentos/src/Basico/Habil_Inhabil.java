package Basico;

public class Habil_Inhabil {

	public static void main(String[] args) {
		int dia=7;
		System.out.println("Dia de la semana Habil o Inhabil");
		switch(dia) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:System.out.println("Dia Habil");
		break;
		
		case 6:
		case 7:System.out.println("Dia Inhabil");
		break;
		
		default:System.out.println("ERROR");
		break;
		}

	}

}
