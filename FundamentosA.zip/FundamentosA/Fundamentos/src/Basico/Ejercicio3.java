package Basico;

public class Ejercicio3 {

	public static void main(String[] args) {
	double ahorro=20,gasto=19;
	if(ahorro>gasto) {
		System.out.println("Solvente");
		ahorro=-gasto;
		gasto=0;
		}
	else
		System.out.println("Quiebra");
	}

}
