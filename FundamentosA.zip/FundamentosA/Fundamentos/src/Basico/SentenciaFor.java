package Basico;

public class SentenciaFor {

	public static void main(String[] args) {
		/*for(inicaliacion;condicion;incremento)
		 * Codigo
		 */
		for(int i=0;i<10;i++)
			System.out.print(i+"\n");
	}

}
