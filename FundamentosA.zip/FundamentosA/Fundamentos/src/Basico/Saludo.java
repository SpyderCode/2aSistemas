package Basico;

public class Saludo{

	public static void main(String[] args) {
		System.out.println("Hola Mundo :v");
		System.out.println("Fundamentos de Programacion");

	}

}
