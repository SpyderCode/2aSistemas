package Basico;
//Sentencia if-else
public class SentenciaIfElse {

	public static void main(String[] args) {
		int x=20;
		if(x<20)
			System.out.println("Se cumple la sentencia --> 1");
		else
			System.out.println("No se cumple condicion -->0");
	}

}
