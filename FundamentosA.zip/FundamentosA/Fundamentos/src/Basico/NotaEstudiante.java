package Basico;
/*
 * Hacer un programa que determine la nota academica de
 * un estudiante
 * Si la calif se encuentra entre 50 y 60--> Asistir a tutoria academica indiv.
 * si la calif se encuentra entre 61 y 70-->A tutoria academica
 * si la calif se encuentra entre 71 y 80--> Sigue Adelante
 * si la calif se encuentra entre 81 y 90-->Puntos Extras
 * si la calif se encuentra entre 91 y 100-->Felicitaciones
 * */
public class NotaEstudiante {

	public static void main(String[] args) {
		int calif=90;
		if ((50<=calif) && (calif<=60))
			System.out.println("Asistir a tutoria academica individual");
		
		else if ((61<=calif) && (calif<=70))
			System.out.println("Asistir a tutoria Academica");
		
		else if ((71<=calif) && (calif<=80))
			System.out.println("Ya mero, sigue adelante");
		
		else if ((81<=calif) && (calif<=90))
			System.out.println("Woo puntos Extras para ti");
		
		else if ((91<=calif) && (calif<=100))
			System.out.println("Ja nerd");
		
		else
			System.out.println("Anda reprobado");
		
		

	}

}
