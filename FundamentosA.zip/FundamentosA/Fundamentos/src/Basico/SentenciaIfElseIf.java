package Basico;
//Sentencia if-else-if
public class SentenciaIfElseIf {

	public static void main(String[] args) {
		int x=20;
		if(x<20)
			System.out.println("Es Menor");
		else if(x>20)
			System.out.println("Es Mayor");
		else
			System.out.println("Son Iguales");

	}

}
