package Basico;

public class TablaWhile {

	public static void main(String[] args) {
		int tabla=1,i=1;
		while(tabla<=10) {
			i=1;
			System.out.println("\nTabla del "+tabla);
		while(i<=10){
			System.out.println(tabla+"X"+i+"="+i*tabla);
			i++;
		}//Fin del while interior
		tabla++;
		}
	}

}
