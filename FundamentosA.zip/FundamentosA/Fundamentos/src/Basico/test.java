package Basico;

public class test {

	public static void main(String[] args) {
		int a=20;
		char b;
		b=(a>10)? 'W':'L';
		System.out.println(b);

	}

}
