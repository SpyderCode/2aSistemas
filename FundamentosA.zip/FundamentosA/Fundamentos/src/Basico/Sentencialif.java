package Basico;
//sentencia if simple
public class Sentencialif {

	public static void main(String[] args) {
		int x=10;
		if (x<20) 
			System.out.println("Se cumple la condicion --> 1");
			
		
	}

}
