package Basico;
//Compara 2 numeros y determina cual es el mayor
public class Mayor2 {

	public static void main(String[] args) {
		int x=100,y=100;
		if (x<y)
			System.out.println(x+" es menor que "+y);
		else if (x>y)
			System.out.println(x+" es mayor que "+y);
		else
			System.out.println(x+" Es igual que "+y);

	}

}
