package Basico;

public class VocalConsonante {

	public static void main(String[] args) {
		char letra='E';
		switch(letra) {
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':System.out.println(letra+" es un vocal");
		break;
		default:System.out.println(letra+" es Consonante");
		break;
		}

	}

}
