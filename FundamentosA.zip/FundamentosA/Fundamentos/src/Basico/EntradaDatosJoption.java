package Basico;

import javax.swing.JOptionPane;

public class EntradaDatosJoption {

	public static void main(String[] args) {
		String name,X,Y;
		int x;
		float y;
		name=JOptionPane.showInputDialog("Ingresa Valor Cadena");
		JOptionPane.showMessageDialog(null, name);
		X=JOptionPane.showInputDialog("Ingresa Valor Entero");
		x=Integer.parseInt(X);
		Y=JOptionPane.showInputDialog("Ingrese Valor Float");
		y=Float.parseFloat(Y);
		JOptionPane.showMessageDialog(null, x);
		JOptionPane.showMessageDialog(null, y);
	}

}
