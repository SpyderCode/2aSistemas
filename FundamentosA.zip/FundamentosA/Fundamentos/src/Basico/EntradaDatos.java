package Basico;

import java.util.Scanner;

public class EntradaDatos {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int x;
		double a;
		String name;
		System.out.println("Ingresa Valor Entero");
		x=in.nextInt();
		System.out.println("Valor entero= "+x);
		System.out.println("Ingrese valor flotante");
		a=in.nextDouble();
		System.out.println("Valor Flotante= "+a);
		in.nextLine();
		System.out.println("Ingrese cadena");
		name=in.nextLine();
		System.out.println("La cadena= "+name);
	}

}
