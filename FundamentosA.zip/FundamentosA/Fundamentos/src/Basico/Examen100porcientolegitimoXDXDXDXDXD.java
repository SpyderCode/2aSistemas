package Basico;

public class Examen100porcientolegitimoXDXDXDXDXD {

	public static void main(String[] args) {
	for(int i=3;i>=1;i--)
		for(int k=1;k<5;k++)
			System.out.println("Hola Amigos XDXDXD");
			
	}

}
