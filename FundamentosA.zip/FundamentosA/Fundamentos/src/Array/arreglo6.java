package Array;

import java.util.Random;

public class arreglo6 {

	public static void main(String[] args) {
		/*hacer un porgrama utilizando arreglos que determine el numero de 0s y 1s que contiene el arreglo
		 * inicializar un arreglo de tama�o 20 con numeros aleatorios de 0s y 1s, utilizar funciones*/
		funcion();
	}

	private static void funcion() {

		Random na = new Random();//funcion para randomizar
		int arreglo[] = new int[20];//se�ala la creacion de un array y dice que hay [] posiciones
		int one = 0, zero = 0;
		
		for (int i = 0; i < arreglo.length; i++)
			arreglo[i] = na.nextInt(2);

		for (int i = 0; i < arreglo.length; i++)
			System.out.print(arreglo[i] + "\t");

		System.out.println("\nCantidad");

		for (int i = 0; i < arreglo.length; i++) {
			if (arreglo[i] == 0)
				zero++;
			else
				one++;
		} // fin del contador
		
		System.out.println("Numero de 0s: " + zero + "\nNumero de 1s: " + one);

	}

}
