package Array;

import java.util.Random;

public class arreglo6_profe {

	public static void main(String[] args) {
		Random na=new Random();
		int array[]=new int[10];
		int i;
		//llenado del arreglo
		for(i=0;i<array.length;i++)
			array[i]=na.nextInt(2);
		//enviar al arreglo al metodo contar()
		contar(array);

	}

	private static void contar(int[] array) {
		int i,cero=0,uno=0;
		for(i=0;i<array.length;i++)
			System.out.print(array[i]+"\t");
		
		for(i=0;i<array.length;i++) {
			if(array[i]==0)
				cero++;
			else
				uno++;
			}
			System.out.println("\nTotal de ceros= "+cero);
			System.out.println("Total de unos= "+uno);
		
		
			
				
	}

}
