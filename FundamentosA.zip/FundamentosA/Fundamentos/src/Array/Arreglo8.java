package Array;

import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Arreglo8 {

	public static void main(String[] args) {
		Integer[] array=new Integer[10];
		Random nr=new Random();
		JTextArea salida = new JTextArea();
		int i;
		String datos="Arreglo\tArreglo Cuad\tArreglo Cubo\n";
		//inicializar el arreglo con numeros aleatorios
		for(i=0;i<array.length;i++)
			array[i]=nr.nextInt(10)+1;
		//imprimir los datos del arreglo
		for(i=0;i<array.length;i++)
			datos+=array[i]+"\t"+(int)Math.pow(array[i], 2)+"\t"+(int)Math.pow(array[i], 3)+"\n";
		
		salida.setText(datos);
		JOptionPane.showMessageDialog(null, salida,"Datos del Arreglo",JOptionPane.ERROR_MESSAGE);

	}

}
