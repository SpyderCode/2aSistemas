package Array;

public class arreglo4 {

	public static void main(String[] args) {
		int arreglo1[] = { 12, 16, 10, 24, 68, 90, 32, 65, 10, 40 };// 10
		int arreglo2[] = { 21, 7, 9, 29, 18, 87, 34, 67, 50, 80 };// 10
		int intercalado[] = new int[20];
		int i, x, j;
		for (i = 0; i < arreglo1.length; i++)
			System.out.print(arreglo1[i] + "\t");
		System.out.println();

		for (i = 0; i < arreglo2.length; i++)
			System.out.print(arreglo2[i] + "\t");

		/*for (i = 0, j = 0; j < intercalado.length; i++, j++) {// Intercalacion
			intercalado[j] = arreglo1[i];
			j++;
			intercalado[j] = arreglo2[i];
		}*/
		for (i=0,j=0,x=1;i<arreglo1.length;i++,j+=2,x+=2) {
			intercalado[j]=arreglo1[i];
			intercalado[x]=arreglo2[i];
		
		}

		System.out.println("\n\n Arreglo Intercalado");
		for (i = 0; i < intercalado.length; i++)
			System.out.print(intercalado[i] + "\t");

		System.out.println("\n\n Numeros Pares");
		for (i = 0; i < intercalado.length; i++)
			if (intercalado[i] % 2 == 0)
				System.out.print(intercalado[i] + "\t");
	}

}
