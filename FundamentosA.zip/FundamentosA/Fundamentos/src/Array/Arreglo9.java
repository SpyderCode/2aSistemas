package Array;

import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Arreglo9 {

	public static void main(String[] args) {
		/*
		 * Realizar un programa que genere dos arreglos (x,y) de forma aleatoria para
		 * n=10 y realice lo siguiente: 
		 * obtener la sumatoria de x 
		 * obtener la sumatoria de y 
		 * obtener la sumatoria de x2 
		 * obtener la sumatoria de y2 
		 * obtener la sumatoria de x*y 
		 * obtener la sumatoria de x2*y2
		 */
		Integer[] array = new Integer[10];
		int arrayx[] = new int[10];
		Random nr = new Random();
		JTextArea salida = new JTextArea();
		int i, sumax = 0, sumay = 0, sumax2 = 0, sumay2 = 0, sumaxy = 0, sumax2y2 = 0;
		String datos = "Arreglo x\tArreglo y\tArreglo x2\tArreglo y2\tArreglo x*y\tArreglo x2*y2\n";
		// inicializar el arreglo con numeros aleatorios
		for (i = 0; i < array.length; i++) {
			array[i] = nr.nextInt(10) + 1;
			arrayx[i] = nr.nextInt(10) + 1;
		} // fin de llenar datos

		for (i = 0; i < array.length; i++)
			datos += arrayx[i] + "\t" + array[i] + "\t\t" + (int) Math.pow(arrayx[i], 2) + "\t\t"
					+ (int) Math.pow(array[i], 2) + "\t" + (array[i] * arrayx[i]) + "\t"
					+ ((int) Math.pow(arrayx[i], 2) * (int) Math.pow(array[i], 2) + "\n");

		for (i = 0; i < array.length; i++) {
			sumax += arrayx[i];
			sumay += array[i];
			sumax2 += Math.pow(arrayx[i], 2);
			sumay2 += Math.pow(array[i], 2);
			sumaxy += array[i] * arrayx[i];
			sumax2y2 += Math.pow(arrayx[i], 2) * Math.pow(array[i], 2);
		}

		salida.setText(datos + "\n" + sumax + "\t" + sumay + "\t\t" + sumax2 + "\t\t" + sumay2 + "\t" + sumaxy + "\t"
				+ sumax2y2);
		JOptionPane.showMessageDialog(null, salida, "Datos del Arreglo", JOptionPane.ERROR_MESSAGE);
	}

}
