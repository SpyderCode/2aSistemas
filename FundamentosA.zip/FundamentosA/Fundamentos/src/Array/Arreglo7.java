package Array;

import java.util.Random;

public class Arreglo7 {

	public static void main(String[] args) {
		Integer[] array=new Integer[10];
		Random nr=new Random();
		int i;
		//inicializar el arreglo con numeros aleatorios
		for(i=0;i<array.length;i++)
			array[i]=nr.nextInt(10)+1;
		//imprimir los datos del arreglo
		System.out.println("Arreglo\tArreglo Cuad\n____________________\n");
		for(i=0;i<array.length;i++)
			System.out.println(array[i]+"\t"+(int)Math.pow(array[i], 2));
			

	}

}
