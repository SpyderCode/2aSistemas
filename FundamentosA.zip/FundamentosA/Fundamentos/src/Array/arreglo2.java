package Array;

public class arreglo2 {

	public static void main(String[] args) {
		int arreglo1[]=new int[10];
		int i=0;
		arreglo1[2]=23;
		arreglo1[8]=10;
		arreglo1[0]=71;
		arreglo1[9]=1;
		System.out.println(arreglo1[2]);
		System.out.println(arreglo1[8]);
		System.out.println(arreglo1[0]);
	}

}
