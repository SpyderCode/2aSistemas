package Array;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Arreglo11 {

	public static void main(String[] args) {
		menu();


	}

	private static void menu() {
		Integer[] x = new Integer[10];
		Integer[] y = new Integer[10];
		Random nr = new Random();
		int i, opc;
		// lenar los arreglos con numeros aleatorios
		for (i = 0; i < x.length; i++) {
			x[i] = nr.nextInt(10) + 1;
			y[i] = nr.nextInt(10) + 1;
		}//fin del for
		do {
		opc = Integer.parseInt(JOptionPane.showInputDialog(null, "1.-Suma\n2.-Multiplica\n3.-Intercala\n4.-Ordena"
				+ "\n5.-Salir","Operaciones con Arreglos", JOptionPane.INFORMATION_MESSAGE));
		
		switch(opc) {
		case 1:suma(x,y);
			break;
		case 2:multiplicacion(x,y);
			break;
		case 3:intercalar(x,y);
			break;
		case 4:orden(x,y);
			break;
		case 5:System.exit(0);
			break;
		default:JOptionPane.showMessageDialog(null, "Opcion Invalida","ERROR",JOptionPane.ERROR_MESSAGE);
			break;
		}//fin del switch
		}while(opc!=5);
	}//fin del menu();

	private static void orden(Integer[] x, Integer[] y) {
		JTextArea salida=new JTextArea();
		String datos="x\tx-sort\ty\ty-sort\n";
		int i;
		//copiar los arreglos x,y en xsort y ysort
		Integer[] xsort=Arrays.copyOf(x, 10);
		Integer[] ysort=Arrays.copyOf(y, 10);
		
		Arrays.sort(xsort);//ordena el arreglo de xsort
		Arrays.sort(ysort);//ordena el arreglo de ysort
		
		for(i=0;i<x.length;i++)
			datos+=x[i]+"\t"+xsort[i]+"\t"+y[i]+"\t"+ysort[i]+"\n";
		salida.setText(datos);
		JOptionPane.showMessageDialog(null, salida);
	}

	private static void intercalar(Integer[] x, Integer[] y) {
		JTextArea salida =new JTextArea();
		String datos = "x\n";
		int[] intercalado=new int[x.length+y.length];
		int i,f,g;
		for (i=0,f=0,g=1;i<x.length;i++,f+=2,g+=2) {
			intercalado[f]=x[i];
			intercalado[g]=y[i];
		}
		for (i=0;i<x.length;i++)
			datos+=x[i]+"\t";
		datos +="\ny\n";
		for (i=0;i<y.length;i++)
			datos+=y[i]+"\t";
		datos +="\nx con y\n";
		for (i=0;i<intercalado.length;i++)
			datos+=intercalado[i]+"\t";
		salida.setText(datos);
		JOptionPane.showMessageDialog(null, salida);
			
		
	}

	private static void multiplicacion(Integer[] x, Integer[] y) {
		// TODO Auto-generated method stub2
		
	}

	private static void suma(Integer[] x, Integer[] y) {
		// TODO Auto-generated method stub
		
	}

}
