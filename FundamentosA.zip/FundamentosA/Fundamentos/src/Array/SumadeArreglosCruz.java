package Array;

public class SumadeArreglosCruz {

	public static void main(String[] args) {
		int arreglo1[] = { 12, 16, 10, 24, 68, 90, 32, 65, 10, 40 };// 10
		int arreglo2[] = { 21, 7, 9, 29, 18, 87, 34, 67, 50, 80 };// 10
		System.out.println("Tama�o del arreglo 1 = " + arreglo1.length);
		System.out.println("Tama�o del arreglo 2 = " + arreglo2.length);
		System.out.println();

		for (int i = 0; i < arreglo1.length; i++)
			System.out.print(arreglo1[i] + "\t");
		System.out.println();

		for (int i = (arreglo2.length - 1); i >= 0; --i)
			System.out.print(arreglo2[i] + "\t");
		System.out.println("\nSuma de los arreglos cruzados");

		for (int i = 0, x = arreglo2.length - 1; i < arreglo1.length; i++, x--)
			System.out.print(arreglo1[i] + arreglo2[x] + "\t");

	}

}
