package Array;

public class Arreglo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arreglo1[]= {23,14,12,45,67,89,29};//7
		
		System.out.println(arreglo1[0]);
		System.out.println(arreglo1[4]);
		
		
	}

}
