package Array;

import java.util.Random;
import java.util.Scanner;

public class arreglo5 {

	public static void main(String[] args) {
		Random na= new Random();
		int arreglo[]=new int[10];
		int num;
		Scanner in=new Scanner(System.in);
		/*arreglo[0]=na.nextInt(10);
		System.out.println(arreglo[0]);*/
		
		for(int i=0;i<arreglo.length;i++)
			arreglo[i]=na.nextInt(10);
		for(int i=0;i<arreglo.length;i++)
			System.out.print(arreglo[i]+"\t");
		
		System.out.println("\nIngrese el numero");
		num=in.nextInt();
		for(int i=0;i<arreglo.length;i++) {
			if(num==arreglo[i])
				System.out.println("Numero "+num+" encontrado en la posicion "+i);
			if(i==arreglo.length-1)
				System.out.println("Terminado!");
		}
		
	}

}
