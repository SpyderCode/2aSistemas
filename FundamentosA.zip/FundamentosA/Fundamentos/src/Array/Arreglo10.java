package Array;

import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Arreglo10 {

	public static void main(String[] args) {
		procesa();
	}

	private static void procesa() {
		Integer[] x=new Integer[10];
		Integer[] y=new Integer[10];
		Random nr=new Random();
		int i,sumaX,sumaY,sumx2,sumy2,sumxy,sumx2y2;
		//llenado de los arreglos con numeros aleatorios
		for(i=0;i<x.length;i++) {
			x[i]=nr.nextInt(10)+1; //numeros del 1 al 10
			y[i]=nr.nextInt(10)+1;
		}
		//mandar llamar los metodos
		sumaX=(int) sumatoriaX(x);//lama al metodo y recibe el arreglo
		sumaY=(int) sumatoriaY(y);
		sumx2=sumatoriaX2(x);
		sumy2=sumatoriaY2(y);
		sumxy=sumatoriaXY(x,y);
		sumx2y2=sumatoriaX2Y2(x,y);
		imprimeDatos(sumaX,sumaY,sumx2,sumy2,sumxy,sumx2y2,x,y);
	}

	private static void imprimeDatos(int sumaX, int sumaY, int sumx2, int sumy2,
			int sumxy, int sumx2y2, Integer[] x,Integer[] y) {
		JTextArea salida=new JTextArea();
		String datos="x\ty\tx2\ty2\tx*y\tx2*y2\n";
		int i;
		for(i=0;i<x.length;i++)//agrega datos
			datos+=x[i]+"\t"+y[i]+"\t"+(int)Math.pow(x[i], 2)+"\t"+(int)Math.pow(y[i], 2)+
			"\t"+(x[i]*y[i])+"\t"+((int)Math.pow(x[i], 2)*(int)Math.pow(y[i], 2))+"\n";
		datos+="_________    ____________   __________    ___________          __________         _____________\n";
		datos+=sumaX+"\t"+sumaY+"\t"+sumx2+"\t"+sumy2+"\t"+sumxy+"\t"+sumx2y2;
		
		salida.setText(datos);//coloca la salida en JTextArea
		JOptionPane.showMessageDialog(null, salida,"Datos de Salida",JOptionPane.INFORMATION_MESSAGE);
		
	}

	private static int sumatoriaX2Y2(Integer[] x, Integer[] y) {
		int sumx2y2=0,i;
		for (i = 0; i < y.length; i++) 
			sumx2y2+=(int)Math.pow(x[i], 2)*(int)Math.pow(y[i], 2);
		return sumx2y2;
	}

	private static int sumatoriaXY(Integer[] x, Integer[] y) {
		int sumxy=0,i;
		for (i = 0; i < x.length; i++) {
			sumxy+=x[i]*y[i];
		}
		return sumxy;
	}

	private static int sumatoriaY2(Integer[] y) {
		int sumay2=0,i;
		for(i=0;i<y.length;i++)
			sumay2+=(int)Math.pow(y[i], 2);
		return sumay2;
	}

	private static int sumatoriaX2(Integer[] x) {
		int sumax2=0,i;
		for(i=0;i<x.length;i++)
			sumax2+=(int)Math.pow(x[i], 2);
		return sumax2;
	}

	private static Object sumatoriaY(Integer[] y) {
		int sumay=0,i;
		for (i= 0; i < y.length; i++)
			sumay+=y[i];
		return sumay;
	}

	private static Object sumatoriaX(Integer[] x) {
		int sumax=0,i;
		for (i=0;i<x.length;i++)
			sumax+=x[i];
		return sumax;
	}

}
