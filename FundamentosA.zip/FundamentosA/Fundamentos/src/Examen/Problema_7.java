package Examen;

import java.util.Scanner;

public class Problema_7 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int alto,ancho;
		System.out.println("Ingrese el alto del terreno");
		alto=in.nextInt();
		System.out.println("Ingrese lo ancho del terreno");
		ancho=in.nextInt();
		System.out.println("El costo es de "+(alto*ancho*3500));

	}

}
