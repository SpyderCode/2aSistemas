package Examen;

import java.util.Scanner;

public class Problema_6 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		String desc;
		int num;
		System.out.println("Ingrese la descripcion");
		desc=in.next();
		System.out.println("Ingresa las unidades");
		num=in.nextInt();
		System.out.println("El costo total de "+desc+" es igual a:"+((num*3.5)+10700));

	}

}
