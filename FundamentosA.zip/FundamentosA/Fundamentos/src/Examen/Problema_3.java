package Examen;

import java.util.Scanner;

public class Problema_3 {

	public static void main(String[] args) {
		int ano;
		Scanner in=new Scanner(System.in);
		System.out.println("Ingrese el a�o");
		ano=in.nextInt();
		if(ano%4==0) {
			if (ano%100==0) {
				if(ano%400==0) {
					System.out.println("El a�o es bisiestro");}
				else System.out.println("El a�o no es bisiestro");
			}
			else System.out.println("El a�o es bisiestro");
		}
			
		else System.out.println("No es bisiestro");

	}

}
