package Examen;

import java.util.Scanner;

public class Problema_5 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int vel;
		System.out.println("Ingrese la velocidad promedio");
		vel=in.nextInt();
		System.out.println("El tiempo necesario es de: "+(163.67/vel));

	}

}
