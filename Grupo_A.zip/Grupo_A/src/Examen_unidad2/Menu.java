package Examen_unidad2;

import javax.swing.JOptionPane;

public class Menu {
   public void menu() {
       Problema1 p1=new Problema1();
       Problema2 p2=new Problema2();
       Problema3 p3=new Problema3();
       
       int opc;
       do {
           opc=Integer.parseInt(JOptionPane.showInputDialog(null,"1.-Problema 1\n2.-Problema 2\n3.-Problema 3\n"
               + "4.-Salir"));
       switch(opc) {
       case 1:p1.ecuacion();
           break;
       case 2:p2.Triangulo();
           break;
       case 3:p3.year();
           break;
       case 4:System.exit(0);
           break;
           default:JOptionPane.showMessageDialog(null, "ERROR","ERROR",JOptionPane.ERROR_MESSAGE);
       }//fin de switch
       }while(opc!=4);//fin de do while
   }
}
