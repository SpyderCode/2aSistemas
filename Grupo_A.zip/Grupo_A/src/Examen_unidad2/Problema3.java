package Examen_unidad2;

import javax.swing.JOptionPane;

public class Problema3 {
    public void year() {
        int year;
        year=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el a�o","A�o bisiesto",JOptionPane.DEFAULT_OPTION));
        if((year%4==0) && ((year%100!=0)||(year%400==0))) {
            JOptionPane.showMessageDialog(null, "El a�o "+year+" es bisiesto!");
        }
        else
            JOptionPane.showMessageDialog(null, "No es bisiesto "+year);
    }
}
