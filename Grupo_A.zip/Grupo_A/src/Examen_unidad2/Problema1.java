package Examen_unidad2;

import javax.swing.JOptionPane;

public class Problema1 {
    public void ecuacion() {
    float a,b,c,d,e,f;
    float x,y;
    a=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese a: "));
    b=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese b: "));
    c=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese c: "));
    d=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese d: "));
    e=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese e: "));
    f=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese f: "));
    x=((c*e)-(b*f))/((a*e)-(b*d));
    y=((a*f)-(c*d))/((a*e)-(b*d));
    JOptionPane.showMessageDialog(null, "x="+x+"\ny="+y,"Respuesta",JOptionPane.DEFAULT_OPTION);
    }
}
