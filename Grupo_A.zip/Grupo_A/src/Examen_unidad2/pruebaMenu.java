package Examen_unidad2;

public class pruebaMenu {

    public static void main(String[] args) {
        Menu m=new Menu();
        m.menu();
        
    }

}
