package Examen_unidad2;

import javax.swing.JOptionPane;

public class Problema2 {
    public void Triangulo() {
        float a,b,c;
        float p,area;
        a=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese a: "));
        b=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese b: "));
        c=Float.parseFloat(JOptionPane.showInputDialog(null,"Ingrese c: "));
        p=(a+b+c)/2;
        area=(float) Math.pow((p*((p-a)*((p-b)*(p-c)))),.5);
        JOptionPane.showMessageDialog(null, "el area es de: "+area,"Area del triangulo",JOptionPane.DEFAULT_OPTION);
    }
}
