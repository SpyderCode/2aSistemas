package vehiculoHerencia;

import javax.swing.JOptionPane;

public class Aereos extends Vehiculo{
    private String empresa;
    private String ruta;
    
    public Aereos(String nombre,String marca,int modelo,String color,double precio,double velocidad,String empresa,String ruta) {
        super(nombre,marca,modelo,color,precio,velocidad);
        this.empresa=empresa;
        this.ruta=ruta;
    }
    
    public String getRuta() {
        return ruta;
    }
    public String getEmpresa() {
        return empresa;
    }
    
    public void setRuta(String ruta) {
        this.ruta=ruta;
    }
    public void setEmpresa(String empresa) {
        this.empresa=empresa;
    }
    
    public void Vuela() {
        JOptionPane.showMessageDialog(null, "Vas bien vas bien al cielo");
    }
    public void Aterriza() {
        JOptionPane.showMessageDialog(null, "Vas bien vas bien, ntc vas a chocar jajaja");
    }
    
    public String toString() {
        return super.toString()+
                "\nEmpresa: "+this.empresa+
                "\nRuta: "+this.ruta;
    }
}
