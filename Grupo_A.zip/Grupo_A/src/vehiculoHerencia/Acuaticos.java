package vehiculoHerencia;

import javax.swing.JOptionPane;

public class Acuaticos extends Vehiculo {
    
    private int capacidad;
    private String categoria;
    
    public Acuaticos(String nombre,String marca,int modelo,String color,double precio,double velocidad,int capacidad,String categoria) {
        super(nombre,marca,modelo,color,precio,velocidad);
        this.capacidad=capacidad;
        this.categoria=categoria;
    }
    
    public String getCategoria() {
        return categoria;
    }
    public int getCapacidad() {
        return capacidad;
    }
    
    public void setCategoria(String categoria) {
        this.categoria=categoria;
        this.capacidad=capacidad;
    }
    public void Navega() {
        JOptionPane.showMessageDialog(null, "Vas bien vas bien");
    }
    
    public String toString() {
        return super.toString()+"\nCapacidad: "+this.capacidad+
                "\nCategoria: "+this.categoria;
    }
}
