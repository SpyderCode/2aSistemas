package vehiculoHerencia;

public class Terrestres extends Vehiculo {
    private String tipo;
    
    public Terrestres(String nombre,String marca,int modelo,String color,double precio,double velocidad,String tipo) {
        super(nombre,marca,modelo,color,precio,velocidad);
        this.tipo=tipo;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo=tipo;
    }
    
    public String toString() {
        return super.toString()+
                "\nTipo: "+this.tipo;
    }

}
