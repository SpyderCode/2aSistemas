package vehiculoHerencia;

import javax.swing.JOptionPane;

public class PruebaVehiculo {

    public static void main(String[] args) {
        Acuaticos a1=new Acuaticos("Seadoo", "Skidoo", 12, "Azul", 21000, 60, 2, "Moto acuatica");
        Aereos ae1=new Aereos("Boeing", "Boeing", 12, "Amarillo", 500000, 20000, "Boeing", "A Japon");
        Terrestres t1=new Terrestres("Porche Carabela", "Porche",1, "Black", 210000, 160,"Deportivo");
        
        JOptionPane.showMessageDialog(null, a1.toString());
        JOptionPane.showMessageDialog(null, ae1.toString());
        JOptionPane.showMessageDialog(null, t1.toString());

    }

}
