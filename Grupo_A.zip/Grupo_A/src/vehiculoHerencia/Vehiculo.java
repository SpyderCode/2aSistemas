package vehiculoHerencia;

import javax.swing.JOptionPane;

public class Vehiculo {
    private String nombre,marca,color;
    private int modelo;
    private double precio,velocidad;
    
    public Vehiculo(String nombre,String marca,int modelo,String color,double precio,double velocidad) {
        this.nombre=nombre;
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
        this.precio=precio;
        this.velocidad=velocidad;
    }
    public String getNombre() {
        return nombre;
    }
    public String getMarca() {
        return marca;
    }
    public int getModelo() {
        return modelo;
    }
    public String getColor() {
        return color;
    }
    public double getPrecio() {
        return precio;
    }
    public double getVelocidad() {
        return velocidad;
    }
    
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setMarca(String marca) {
        this.marca=marca;
    }
    public void setModelo(int modelo) {
        this.modelo=modelo;
    }
    public void setColor(String color) {
        this.color=color;
    }
    public void setPrecio(double precio) {
        this.precio=precio;
    }
    public void setVelocidad(double velocidad) {
        this.velocidad=velocidad;
    }
    
    public void Encender() {
        JOptionPane.showMessageDialog(null, "Enciende, vroom vroom");
    }
    public void Apagar() {
        JOptionPane.showMessageDialog(null, "Se apaga");
    }
    public void Acelerar() {
        JOptionPane.showMessageDialog(null, "Acelerando a 200 Km/h");
    }
    public void Frenar() {
        JOptionPane.showMessageDialog(null, "Aqui no hay frenos 7u7");
    }
    
    public String toString() {
        return "Nombre: "+this.nombre+
                "\nMarca: "+this.marca+
                "\nModelo: "+this.modelo+
                "\nColor: "+this.color+
                "\nPrecio: "+this.precio+
                "\nVelocidad Max: "+this.velocidad;
    }
}
