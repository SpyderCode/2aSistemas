package herenciaVehiculo;

public class Deportivo extends Vehiculo{
    private String potencia;
    private String dise�o;
    
    public Deportivo(String matricula,String modelo,String marca,String color,double precio,String potencia,String dise�o) {
        super(matricula,modelo,marca,color,precio);
        this.potencia=potencia;
        this.dise�o=dise�o;
    }
    
    //Gets
    public String getPotencia() {
        return potencia;
    }
    public String getDise�o() {
        return dise�o;
        
    }
    
    //Sets
    public void setPotencia(String potencia) {
        this.potencia=potencia;;
    }
    public void setDise�o(String dise�o) {
        this.dise�o=dise�o;
    }
    public String toString() {
        return super.toString()+"\nPotencia: "+getPotencia()+
                "\nDise�o: "+getDise�o();
    }
}

