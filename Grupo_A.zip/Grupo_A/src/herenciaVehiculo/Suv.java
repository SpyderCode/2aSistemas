package herenciaVehiculo;

public class Suv extends Vehiculo{
    private int capacidad;
    private int Npuertas;
    
    public Suv(String matricula,String modelo,String marca,String color,double precio,int capacidad,int Npuertas) {
        super(matricula,modelo,marca,color,precio);
        this.capacidad=capacidad;
        this.Npuertas=Npuertas;
    }
    
    //Gets
    public int getCapacidad() {
        return capacidad;
    }
    public int getNpuertas() {
        return Npuertas;
        
    }
    
    //Sets
    public void setCapacidad(int capacidad) {
        this.capacidad=capacidad;
    }
    public void setNpuertas(int Npuertas) {
        this.Npuertas=Npuertas;
    }
    public String toString() {
        return super.toString()+"\nCapacidad: "+this.capacidad+
                "\nNumero de Puertas: "+this.Npuertas;
    }
}
