package herenciaVehiculo;

import javax.swing.JOptionPane;

public class pruebaVehiculo {

    public static void main(String[] args) {
        Deportivo d1=new Deportivo("AGF-123-Z", "Fiat", "Toyota", "Cafe", 23500, "150 HP", "Convertible");
        JOptionPane.showMessageDialog(null, d1.toString());
        Suv s1=new Suv("AAD-123-K", "Civic", "Honda", "NEGRO COMO MI CORAZON", 8000, 8, 4);
        Sedan se1=new Sedan(null, null, null, null, 0, 0, null);

    }

}
