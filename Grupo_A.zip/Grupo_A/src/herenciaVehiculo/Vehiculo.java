package herenciaVehiculo;

public class Vehiculo {
    private String matricula;
    private String modelo;
    private String marca;
    private String color;
    private double precio;
    
    public Vehiculo(String matricula,String modelo,String marca,String color,double precio) {
        this.matricula=matricula;
        this.modelo=modelo;
        this.marca=marca;
        this.color=color;
        this.precio=precio;
    }
    //gets
    public String getMatricula() {
        return matricula;
    }
    public String getModelo() {
        return modelo;
    }
    public String getMarca() {
        return marca;
    }
    public String getColor() {
        return color;
    }
    public double getPrecio() {
        return precio;
    }
    
    //Sets
    public void setMatricula(String matricula) {
        this.matricula=matricula;
    }
    public void setModelo(String modelo) {
        this.modelo=modelo;
    }
    public void setMarca(String marca) {
        this.marca=marca;
    }
    public void setColor(String color) {
        this.color=color;
    }
    public void setPrecio(double precio) {
        this.precio=precio;
    }
    public String toString() {
        return "Matricula: "+this.matricula+
                "\nModelo: "+this.modelo+
                "\nMarca: "+this.marca+
                "\nColor: "+this.color+
                "\nPrecio: "+this.precio;
    }
}
