package herenciaVehiculo;

public class Sedan extends Vehiculo{
    private double rendimiento;
    private String pEquipaje;
    
    public Sedan(String matricula,String modelo,String marca,String color,double precio,double rendimiento,String pEquipaje) {
        super(matricula,modelo,color,marca,precio);
        this.rendimiento=rendimiento;
        this.pEquipaje=pEquipaje;
    }
    
    //Gets
    public double getRendimiento() {
        return rendimiento;
    }
    public String getPEquipaje() {
        return pEquipaje;
        
    }
    
    //Sets
    public void setRendimiento(double rendimiento) {
        this.rendimiento=rendimiento;
    }
    public void setPEquipaje(String pEquipaje) {
        this.pEquipaje=pEquipaje;
    }
    public String toString() {
        return super.toString()+"\nRendimiento: "+this.rendimiento+
                "\nPorta Equipaje: "+this.pEquipaje;
    }
    
}
