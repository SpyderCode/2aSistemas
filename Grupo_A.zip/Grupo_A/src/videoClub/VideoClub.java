package videoClub;

import javax.swing.JOptionPane;

public class VideoClub {

    public static void main(String[] args) {
        Clientes c1=new Clientes(007, "Juan Juanito", 22, "Masculino", "Prv. las cumbre 120", "Jperez@gmail.com");
        Peliculas p1=new Peliculas("Terror", 001, "El conjuro", "120 min", "B15");
        Rentas r1=new Rentas(45, 7, "Marzo", 2018, 2, c1, p1);
        
        JOptionPane.showMessageDialog(null,
               
                "Nombre: "+r1.getCliente().getNombre()+
                "\nId: "+r1.getCliente().getId()+
                "\nRento: "+r1.getPelicula().getNombre()+
                "\nGenero: "+r1.getPelicula().getCategoria()+
                "\nFecha de Renta: "+r1.getDia()+" "+r1.getMes()+" "+r1.getA�o(),
                
                "Datos del cliente",JOptionPane.INFORMATION_MESSAGE);

    }

}
