package videoClub;

public class Rentas {
    private double costo;
    private int dia;
    private String mes;
    private int a�o;
    private int diasRenta;
    private Clientes clientes;
    private Peliculas pelicula;

    public Rentas(double costo,int dia,String mes,int a�o,int diasRenta,Clientes clientes,Peliculas pelicula) {
        this.costo=costo;
        this.dia=dia;
        this.mes=mes;
        this.a�o=a�o;
        this.diasRenta=diasRenta;
        this.clientes=clientes;
        this.pelicula=pelicula;
    }
    
    public double getCosto() {
        return costo;
    }
    public int getDia() {
        return dia;
    }
    public String getMes() {
        return mes;
    }
    public int getA�o() {
        return a�o;
    }
    public int getDiasRenta() {
        return diasRenta;
    }
    public Clientes getCliente() {
        return clientes;
    }
    public Peliculas getPelicula() {
        return pelicula;
    }
    
    public void setCosto(double costo) {
        this.costo=costo;
    }
    public void setDia(int dia) {
        this.dia=dia;
    }
    public void setMes(String mes) {
        this.mes=mes;
    }
    public void setA�o(int a�o) {
        this.a�o=a�o;
    }
    public void setCliente(Clientes cliente) {
        this.clientes=cliente;
    }
    public void setPelicula(Peliculas pelicula) {
        this.pelicula=pelicula;
    }
}
