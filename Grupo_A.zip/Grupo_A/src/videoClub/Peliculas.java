package videoClub;

public class Peliculas {
    private String categoria;
    private int id;
    private String nombre;
    private String duracion;
    private String clasificacion;

    public Peliculas(String categorias,int id,String nombre,String duracion,String clasificacion) {
        this.categoria=categorias;
        this.id=id;
        this.nombre=nombre;
        this.duracion=duracion;
        this.clasificacion=clasificacion;
    }
    
    public String getCategoria() {
        return categoria;
    }
    public int getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDuracion() {
        return duracion;
    }
    public String getClasificacion() {
        return clasificacion;
    }
    
    public void setCategoria(String categoria) {
        this.categoria=categoria;
    }
    public void setId(int id) {
        this.id=id;
    }
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setDuracion(String duracion) {
        this.duracion=duracion;
    }
    public void setClasificacion(String clasificacion) {
        this.clasificacion=clasificacion;
    }
    
}
