package herenciaFutbol;

import javax.swing.JOptionPane;

public class SeleccionFutbol {
    private int id;
    private String nombre;
    private String apellido;
    private double peso;
    private int edad;
    
    public SeleccionFutbol(int id,String nombre,String apellido,double peso,int edad) {
        this.id=id;
        this.nombre=nombre;
        this.apellido=apellido;
        this.peso=peso;
        this.edad=edad;
    }
    
    /*
     * Gets
     * */
    
    public int getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public double getPeso() {
        return peso;
    }
    public int getEdad() {
        return edad;
    }
    
    /*
     * SETS
     */
    
    public void setId(int id) {
        this.id=id;
    }
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setApellido(String apellido) {
        this.apellido=apellido;
    }
    public void setPeso(double peso) {
        this.peso=peso;
    }
    public void setEdad(int edad) {
        this.edad=edad;
    }
    
    public void Concentrarse() {
        JOptionPane.showMessageDialog(null, "Debe concentrarse");
    }
    public void Viajar() {
        JOptionPane.showMessageDialog(null, "Debe Viajar");
    }
    
    public String toString() {
        return "\nId: "+this.id+
                "\nNombre Completo: "+this.nombre+" "+this.apellido+
                "\nPeso: "+this.peso+
                "\nEdad: "+this.edad;
    }
}
