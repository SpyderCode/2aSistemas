package herenciaFutbol;

import javax.swing.JOptionPane;

public class Entrenador extends SeleccionFutbol{
    public String idFederacion;
    
    public Entrenador(int id,String nombre,String apellido,double peso,int edad,String idFederacion) {
        super(id,nombre,apellido,peso,edad);
        this.idFederacion=idFederacion;
    }
    
    public String getIdFederacion() {
        return idFederacion;
    }
    
    public void setIdFederacion(String idFederacion) {
        this.idFederacion=idFederacion;
    }
    
    public void DirigePartido() {
        JOptionPane.showMessageDialog(null, "DIRIGE,FUE PENALTY");
    }
    public void DirigeEntrenamiento() {
        JOptionPane.showMessageDialog(null, "Diles una historia de hace mil a�os");
    }
    
    public String toString() {
        return super.toString()+
                "\nId de la Federacion: "+this.idFederacion;
    }
}
