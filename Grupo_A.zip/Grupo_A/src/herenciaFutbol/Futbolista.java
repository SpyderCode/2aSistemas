package herenciaFutbol;

import javax.swing.JOptionPane;

public class Futbolista extends SeleccionFutbol {
    
    private String posicion;
    private int numero;
    
    public Futbolista(int id,String nombre,String apellido,double peso,int edad,String posicion,int numero) {
        super(id,nombre,apellido,peso,edad);
        this.posicion=posicion;
        this.numero=numero;
    }
    
    public String getPosicion() {
        return posicion;
    }
    public int getNumero() {
        return numero;
    }
    
    public void setPosicion(String posicion) {
        this.posicion=posicion;
    }
    
    public void setNumero(int numero) {
        this.numero=numero;
    }
    
    public void JugarPartido() {
        JOptionPane.showMessageDialog(null, "Debe entrar");
    }
    public void Entrenar() {
        JOptionPane.showMessageDialog(null, "Le falta entrenar");
    }
    
    public String toString() {
        return super.toString()+
                "\nPosicion: "+this.getPosicion()+
                "\nNumero: "+this.numero;
    }
    
}
