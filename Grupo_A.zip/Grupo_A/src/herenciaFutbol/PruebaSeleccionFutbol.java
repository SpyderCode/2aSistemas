package herenciaFutbol;

import javax.swing.JOptionPane;

public class PruebaSeleccionFutbol {

    public static void main(String[] args) {
       Futbolista f1=new Futbolista(1233221, "Chicha", "Rito", 140, 29, "Sepa no veo fut", 12);
       Masajista m1=new Masajista(13412, "Manos", "Suaves", 200, 60, "Espalda", 40);
       Entrenador e1=new Entrenador(3,"Juan", "Portillo", 212, 31, "ZAC-12-G");
       
       JOptionPane.showMessageDialog(null, f1.toString());
       JOptionPane.showMessageDialog(null, m1.toString());
       JOptionPane.showMessageDialog(null, e1.toString());

    }

}
