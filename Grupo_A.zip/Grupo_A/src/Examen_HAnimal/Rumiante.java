package Examen_HAnimal;

public class Rumiante extends Herbivoro{
	private int Vregurgitado;
	private String defensa;
	private int numdepanza;
	
	public Rumiante(String nombre,double peso,int edad,String sexo,String habitat,String comida,String predator,String CdeComida,int Vregurgitado,String defensa, int numdepanza) {
		super(nombre, peso, edad, sexo, habitat, comida, predator, CdeComida);
		this.Vregurgitado=Vregurgitado;
		this.defensa=defensa;
		this.numdepanza=numdepanza;
	}
	
	public int getVregurgitado() {
		return this.Vregurgitado;
	}
	public String getDefensa() {
		return defensa;
	}
	public int getNumdepanza() {
		return numdepanza;
	}
	
	public void setVregurgitado(int Vregurgitado) {
		this.Vregurgitado=Vregurgitado;
	}
	public void setDefensa(String defensa) {
		this.defensa=defensa;
	}
	public void setNumdepanza(int numdepanza) {
		this.numdepanza=numdepanza;
	}
	
	public String toString() {
		return super.toString()+
				"\nVeces que regurgitan: "+this.Vregurgitado+
				"\nDefensa: "+this.defensa+
				"\nNumero de panzas: "+this.numdepanza;
	}
}
