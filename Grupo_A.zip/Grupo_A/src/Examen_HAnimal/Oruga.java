package Examen_HAnimal;

public class Oruga extends Insecto{
	private String Color;
	
	public Oruga(String nombre,double peso,int edad,String sexo,String habitat,String comida,String predator,String CdeComida,String alas,int numdepies,String Color) {
		super(nombre, peso, edad, sexo, habitat, comida, predator, CdeComida, alas, numdepies);
		this.Color=Color;
	}
	
	public String getColor() {
		return Color;
	}
	public void setColor(String Color) {
		this.Color=Color;
	}
	
	public String toString() {
		return super.toString()+"\nColor: "+this.Color;
	}

}
