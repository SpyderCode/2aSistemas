package Examen_HAnimal;

public class Vaca extends Rumiante{
	private double leche;
	public Vaca(String nombre,double peso,int edad,String sexo,String habitat,String comida,String predator,String CdeComida,int Vregurgitado,String defensa, int numdepanza,int leche) {
		super(nombre, peso, edad, sexo, habitat, comida, predator, CdeComida, Vregurgitado, defensa, numdepanza);
		this.leche=leche;
	}
	
	public double getleche() {
		return leche;
	}
	public void setleche(double leche) {
		this.leche=leche;
	}
	
	public String toString() {
		return super.toString()+"\nCantidad de leche: "+this.leche;
	}
}
