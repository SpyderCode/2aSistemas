package Examen_HAnimal;

public class Alce extends Rumiante{
	private String Tama�odeCuernos;
	
	public Alce(String Tama�odeCuernos,String nombre,double peso,int edad,String sexo,String habitat,String comida,String predator,String CdeComida,int Vregurgitado,String defensa, int numdepanza) {
		super(nombre, peso, edad, sexo, habitat, comida, predator, CdeComida, Vregurgitado, defensa, numdepanza);
		this.Tama�odeCuernos=Tama�odeCuernos;
	}
	public String getTama�odeCuernos() {
		return Tama�odeCuernos;
	}
	public void setTama�odeCuernos(String Tama�odeCuernos) {
		this.Tama�odeCuernos=Tama�odeCuernos;
	}
	
	public String toString() {
		return super.toString()+"\nTama�o de Cuernos: "+this.Tama�odeCuernos;
	}
}
