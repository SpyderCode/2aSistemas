package Examen_HAnimal;

public class Herbivoro extends Animal{
	private String comida;
	private String predator;
	private String CdeComida;
	
	public Herbivoro(String nombre,double peso,int edad,String sexo,String habitat,String comida,String predator,String CdeComida) {
		super(nombre,peso,edad,sexo,habitat);
		this.comida=comida;
		this.predator=predator;
		this.CdeComida=CdeComida;
	}
	
	public String getComida() {
		return comida;
	}
	public String getPredator() {
		return predator;
	}
	public String getCdeComida() {
		return CdeComida;
	}
	
	public void setComida(String comida) {
		this.comida=comida;
	}
	public void setPredator(String predator) {
		this.predator=predator;
	}
	public void setCdeComida(String CdeComida) {
		this.CdeComida=CdeComida;
	}
	
	public String toString() {
		return super.toString()+
				"\nComida: "+this.comida+
				"\nPredator natural: "+this.predator+
				"\nCantidad de comida: "+this.CdeComida;
		
	}
}
