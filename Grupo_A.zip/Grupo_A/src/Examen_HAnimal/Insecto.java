package Examen_HAnimal;

public class Insecto extends Herbivoro{
	private String alas;
	private int numdepies;
	
	public Insecto(String nombre,double peso,int edad,String sexo,String habitat,String comida,String predator,String CdeComida,String alas,int numdepies) {
		super(nombre, peso, edad, sexo, habitat, comida, predator, CdeComida);
		this.alas=alas;
		this.numdepies=numdepies;
		
	}
	
	public String getAlas() {
		return alas;
	}
	public int getNumdepies() {
		return numdepies;
	}
	
	public void setAlas(String alas) {
		this.alas=alas;
	}
	public void setNumdepies(int numdepies) {
		this.numdepies=numdepies;
	}
	
	public String toString() {
		return super.toString()+
				"\nAlas: "+this.alas+
				"\nNumero de pies: "+this.numdepies;
	}
}
