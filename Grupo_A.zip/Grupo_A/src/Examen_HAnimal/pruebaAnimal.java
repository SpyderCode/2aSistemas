package Examen_HAnimal;

import javax.swing.JOptionPane;

public class pruebaAnimal {

	public static void main(String[] args) {
		Termita t=new Termita("Kalotermes flavicollis", .1, 1, "M", "Desierto", "Madera", "Aves", "5 Gramos", "No", 6, "Termita de la madera h�meda");
		Oruga o=new Oruga("Larva", .2, 1, "F", "Parque", "Hojas de plantas", "Aves", "Todo lo que puedan", "No en esta etapa",16, "Verda");
		Vaca v=new Vaca("Bos primigenius taurus", 40, 15, "F", "Granjas", "pasto", "Humanos", "10% de su peso", 4, "Granjeros", 4, 9);
		Alce a=new Alce("Grandes", "Alces alces", 50, 3, "M"," Monta�as", "Arbusto", "Lobos", "Bien mucho", 4, "Cuernos", 4);
		
		JOptionPane.showMessageDialog(null, t,"Termita",JOptionPane.DEFAULT_OPTION);
		JOptionPane.showMessageDialog(null, o,"Oruga",JOptionPane.DEFAULT_OPTION);
		JOptionPane.showMessageDialog(null, v,"Vaca",JOptionPane.DEFAULT_OPTION);
		JOptionPane.showMessageDialog(null, a,"Alce",JOptionPane.DEFAULT_OPTION);

	}

}
