package empresa;

import javax.swing.JOptionPane;

public class Empresa {

    public static void main(String[] args) {
        Empleados e1=new Empleados(1732181, "Juan", "Pablito", "Calle 1", "Juanjuanito@juan.juan.mx", 69/* 7u7 */, "313-123-2133");
        Puesto p1=new Puesto("T-572", "Vendedor de tacos", 100000, 69);
        Nomina n1=new Nomina(e1, p1, 10, 20);
        
        JOptionPane.showMessageDialog(null, 
                "Empleado: "+n1.getEmpleados().getNombre()+" "+n1.getEmpleados().getApellido()+
                "\nId: "+n1.getEmpleados().getId()+
                "\nPuesto: "+n1.getPuesto().getNombre()+
                "\nDias trabajados: "+n1.getPuesto().getDtrabajados()+
                "\nDescuento de: "+n1.getDescuentos()+"%");

    }

}
