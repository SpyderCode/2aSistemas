package empresa;

public class Nomina {
private Empleados empleado;
private Puesto puesto;
private int hextras;
private double descuentos;

    public Nomina(Empleados empleado,Puesto puesto,int hextras,double descuentos) {
        this.empleado=empleado;
        this.puesto=puesto;
        this.hextras=hextras;
        this.descuentos=descuentos;
    }
    
    public Empleados getEmpleados() {
        return empleado;
    }
    public Puesto getPuesto() {
        return puesto;
    }
    public int getHextras() {
        return hextras;
    }
    public double getDescuentos() {
        return descuentos;
    }
    
    public void setEmpleado(Empleados empleado) {
        this.empleado=empleado;
    }
    public void setPuesto(Puesto puesto) {
        this.puesto=puesto;
    }
    public void setHextras(int hextras) {
        this.hextras=hextras;
    }
    public void setDescuentos(double descuentos) {
        this.descuentos=descuentos;
    }
}
