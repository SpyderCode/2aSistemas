package empresa;

public class Puesto {
private String id;
private String nombre;
private double sueldo;
private int dtrabajados;

    public Puesto(String id,String nombre,double sueldo,int dtrabajados) {
        this.id=id;
        this.nombre=nombre;
        this.sueldo=sueldo;
        this.dtrabajados=dtrabajados;
    }
    
    //GETS
    public String getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public double getSueldo() {
        return sueldo;
    }
    public int getDtrabajados() {
        return dtrabajados;
    }
    
    //Sets
    
    public void setId(String id) {
        this.id=id;
    }
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setSueldo(double sueldo) {
        this.sueldo=sueldo;
    }
    public void setDtrabajados(int dtrabajados) {
        this.dtrabajados=dtrabajados;
    }
}
