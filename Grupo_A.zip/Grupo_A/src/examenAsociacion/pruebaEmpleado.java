package examenAsociacion;

import javax.swing.JOptionPane;

public class pruebaEmpleado {

    public static void main(String[] args) {
        Empleado empleado1 = new Empleado("Gian Luka", "Guerron", "Gian@gmail.com", "Italanis", 2500, "Chef", 38,"Masculino"
                ,120,"Italiano");
        Empleado empleado2 = new Empleado("Pedro", "Lopez", "pedrolopez@gmail.com", "Corona", 1500, "Ventas", 26,"Masculino"
                ,60,"Alemania");
        Empleado empleado3 = new Empleado("Mariana", "Madrigal", "Mariana@gmail.com", "Liverpool", 4500, "Ejecutiva",24,"Femenino"
                ,60,"Francia");

        // empleado 1
        JOptionPane.showMessageDialog(null, empleado1.toString(), "Empleado 1", JOptionPane.DEFAULT_OPTION);
        empleado1.Atender();
        empleado1.Preparar();
        empleado1.setApellido("Pastel");
        empleado1.setPeso(1000);
        JOptionPane.showMessageDialog(null, empleado1.toString(), "Empleado 1", JOptionPane.DEFAULT_OPTION);

        // empleado 2
        JOptionPane.showMessageDialog(null, empleado2.toString(), "Empleado 2", JOptionPane.DEFAULT_OPTION);
        empleado2.Atender();
        empleado2.Surtir();
        empleado2.setEmpresa("Corona de Calera");
        empleado2.setOrigen("Mexico");
        JOptionPane.showMessageDialog(null, empleado2.toString(), "Empleado 2", JOptionPane.DEFAULT_OPTION);

        // empleado 3
        JOptionPane.showMessageDialog(null, empleado3.toString(), "Empleado 3", JOptionPane.DEFAULT_OPTION);
        empleado3.Atender();
        empleado3.Administrar();
        empleado3.setEdad(40);
        empleado3.setEmpresa("Ninguna");
        JOptionPane.showMessageDialog(null, empleado3.toString(), "Empleado 3", JOptionPane.DEFAULT_OPTION);

    }

}
