package examenAsociacion;

import javax.swing.JOptionPane;

public class Empleado {
    private String nombre;
    private String apellido;
    private String correo;
    private String empresa;
    private double salario;
    private String ocupacion;
    private int edad;
    private String sexo;
    private int peso;
    private String origen;
    
    public Empleado(String nombre,String apellido,String correo,String empresa,double salario,String ocupacion,int edad,String sexo
            ,int peso,String origen) {
        this.nombre=nombre;
        this.apellido=apellido;
        this.correo=correo;
        this.empresa=empresa;
        this.salario=salario;
        this.ocupacion=ocupacion;
        this.edad=edad;
        this.sexo=sexo;
        this.peso=peso;
        this.origen=origen;
    }
    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public String getCorreo() {
        return correo;
    }
    public String getEmpresa() {
        return empresa;
    }
    public double getSalario() {
        return salario;
    }
    public String getOcupacion() {
        return ocupacion;
    }
    public int getEdad() {
        return edad;
    }
    private String getSexo() {
        return sexo;
    }
    private int getPeso() {
        return peso;
    }
    public String getOrigen() {
        return origen;
    }
    
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setApellido(String apellido) {
        this.apellido=apellido;
    }
    public void setCorreo(String correo) {
        this.correo=correo;
    }
    public void setEmpresa(String empresa) {
        this.empresa=empresa;
    }
    public void setSalario(double salario) {
        this.salario=salario;
    }
    public void setOcupacion(String ocupacion) {
        this.ocupacion=ocupacion;
    }
    public void setEdad(int edad) {
        this.edad=edad;
    }
    public void setSexo(String sexo) {
        this.sexo=sexo;
    }
    public void setPeso(int peso) {
        this.peso=peso;
    }
    public void setOrigen(String origen) {
        this.origen=origen;
    }
    
    
    public void Atender() {
        JOptionPane.showMessageDialog(null, "Debe atender");
    }
    public void Surtir() {
        JOptionPane.showMessageDialog(null, "Hay que surtir");
    }
    public void Preparar() {
        JOptionPane.showMessageDialog(null, "Preparate");
    }
    public void Administrar() {
        JOptionPane.showMessageDialog(null, "Se debe administrar");
    }
    public void Cobrar() {
        JOptionPane.showMessageDialog(null, "cobrarle TODOOOOOO");
    }
    
    public String toString() {
        return "Nombre: "+getNombre()+
                "\nApellido: "+getApellido()+
                "\nCorreo: "+getCorreo()+
                "\nEmpresa: "+getEmpresa()+
                "\nSalario: "+getSalario()+
                "\nOcupacion: "+getOcupacion()+
                "\nEdad: "+getEdad()+
                "\nSexo: "+getSexo()+
                "\npeso: "+getPeso()+
                "\nPais de Origen: "+getOrigen();
    }
}

