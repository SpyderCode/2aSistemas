package asociacion;

import javax.swing.JOptionPane;

public class Pokemon {
private String nombre;
private String especie;
private String tipo;
private double peso;
private double altura;
private String habitat;

    public Pokemon(String nombre,String especie,String tipo,double peso,double altura,String habitat) {
        this.nombre=nombre;
        this.especie=especie;
        this.tipo=tipo;
        this.peso=peso;
        this.altura=altura;
        this.habitat=habitat;
    }
    public String getNombre() {
        return nombre;
    }
    public String getEspecie() {
        return especie;
    }
    public String getTipo() {
        return tipo;
    }
    public double getPeso() {
        return peso;
    }
    public double getAltura() {
        return altura;
    }
    public String getHabitat() {
        return habitat;
    }
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setEspecie(String especie) {
        this.especie=especie;
    }
    public void setTipo(String tipo) {
        this.tipo=tipo;
    }
    public void setPeso(double peso) {
        this.peso=peso;
    }
    public void setAltura(double altura) {
        this.altura=altura;
    }
    public void setHabitat(String habitat) {
        this.habitat=habitat;
    }
    public void Comer() {
        JOptionPane.showMessageDialog(null, "El pokemon esta comiendo");
    }
    public void Dormir() {
        JOptionPane.showMessageDialog(null, "EL POKEMON DUERME, CALLATE");
    }
    public void Pelear() {
        JOptionPane.showMessageDialog(null, "mira que bonitos, pelean");
    }
    public void Saltar() {
        JOptionPane.showMessageDialog(null, "Salta");
    }
    public void Correr() {
        JOptionPane.showMessageDialog(null, "corre de ti, monstro");
    }
    public String toString() {
        return "Nombre: "+getNombre()+
                "\nEspecie: "+getEspecie()+
                "\nTipo: "+getTipo()+
                "\nPeso: "+getPeso()+
                "\nAltura: "+getAltura()+
                "\nHabitat: "+getHabitat();
    }
}
