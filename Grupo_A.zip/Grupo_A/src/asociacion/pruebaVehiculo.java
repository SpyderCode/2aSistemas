package asociacion;

import javax.swing.JOptionPane;

public class pruebaVehiculo {

    public static void main(String[] args) {
        Automovil Coche1=new Automovil("Seat", "Leon", "rojo", "ADF-123-A", 1200000);
        Automovil Coche2=new Automovil("Ferrari", "Enzo", "rojo", "AMK-321-T", 555000);
        Automovil Coche3=new Automovil("Renault", "Clio", "Blanco", "AHG-987-Z", 85000);
        
        JOptionPane.showMessageDialog(null, Coche1.toString());
        
        JOptionPane.showMessageDialog(null, Coche2.toString());
        
        JOptionPane.showMessageDialog(null, Coche3.toString());
    }

}
