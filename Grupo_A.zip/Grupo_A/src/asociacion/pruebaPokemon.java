package asociacion;

import javax.swing.JOptionPane;

public class pruebaPokemon {

    public static void main(String[] args) {
        Pokemon pokemon1=new Pokemon("Charmeleon", "Llama", "Fuego", 19, 1.1,"monta�a");
        Pokemon pokemon2=new Pokemon("Pidgeotto", "Pajaro", "Volador", 30, 1.1, "Bosque");
        Pokemon pokemon3=new Pokemon("Pikachu", "Raton", "Electrico", 6.5, .5, "Bosque");
        JOptionPane.showMessageDialog(null, pokemon1.toString());
        JOptionPane.showMessageDialog(null, pokemon2.toString());
        JOptionPane.showMessageDialog(null, pokemon.toString());
    }

}
