package asociacion;

import javax.swing.JOptionPane;

public class Automovil {
private String marca;
private String modelo;
private String color;
private String matricula;
private double precio;

    public Automovil(String marca, String modelo, String color, String matricula,double precio) {
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
        this.matricula=matricula;
        this.precio=precio;
    }
    public String getMarca() {
        return marca;
    }
    public String getModelo() {
        return modelo;
    }
    public String getColor() {
        return color;
    }
    public String getMatricula() {
        return matricula;
    }
    public double getPrecio() {
        return precio;
    }
    //metodos sets
    public void setMarca(String marca) {
        this.marca=marca;
    }
    public void setModelo(String modelo) {
        this.modelo=modelo;
    }
    public void setColor(String color) {
        this.color=color;
    }
    public void setMatricula(String matricula) {
        this.matricula=matricula;
    }
    public void setPrecio(double precio) {
        this.precio=precio;
    }
    //muestra los datos
   public void Arrancar() {
       JOptionPane.showMessageDialog(null, "El vehiculo arranco");
   }
   public void Detenerse() {
       JOptionPane.showMessageDialog(null, "El vehiculo se detuvo");
   }
   public void Acelerar() {
       JOptionPane.showMessageDialog(null, "El vehiculo esta acelerando");
   }
   public void Frenar() {
       JOptionPane.showMessageDialog(null, "El vehiculo frena");
   }
   public String toString() {
       return "Marca: "+getMarca()+
               "\nModelo: "+getModelo()+
               "\nColor: "+getMarca()+
               "\nMatricula: "+getMatricula()+
               "\nPrecio: "+getPrecio();
   }

}
