package examen_Hotel;

public class Huesped {
    private String nombre;
    private String apellido;
    private String curp;
    
    
    public Huesped(String nombre,String apellido,String curp) {
        this.nombre=nombre;
        this.apellido=apellido;
        this.curp=curp;
    }
    
    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public String getCurp() {
        return curp;
    }
    
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setApellido(String apellido) {
        this.apellido=apellido;
    }
    public void setCurp(Habitacion habitacion) {
        this.curp=curp;
    }
   
}
