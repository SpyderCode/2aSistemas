package examen_Hotel;

public class Servicios {
    
    private String wifipass;
    private String pisina;
    private String limpieza;
    private String lestacionamiento;
    
    public Servicios(String wifipass,String pisina,String limpieza,String lestacionamiento) {
        this.wifipass=wifipass;
        this.pisina=pisina;
        this.limpieza=limpieza;
        this.lestacionamiento=lestacionamiento;
    }
    public String getWifipass() {
        return wifipass;
    }
    public String getPisina() {
        return pisina;
    }
    public String getLimpieza() {
        return limpieza;
    }
    public String getLestacionamiento() {
        return lestacionamiento;
    }
    
    public void setWifipass(String wifipass) {
        this.wifipass=wifipass;
    }
    public void setPisina(String pisina) {
        this.pisina=pisina;
    }
    public void setLimpieza(String limpieza) {
        this.limpieza=limpieza;
    }
    public void setLestacionamiento(String lestacionamiento) {
        this.lestacionamiento=lestacionamiento;
    }
    
}
