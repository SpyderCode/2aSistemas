package examen_Hotel;

import javax.swing.JOptionPane;

public class Hotel {

    public static void main(String[] args) {
        Huesped hu1=new Huesped("Juan", "Gonzales", "JUGG93129921");
        Empleados e1=new Empleados("Pedro", "Reparacion", 500);
        Habitacion ha1=new Habitacion("Alta clase", 20, 2, 150);
        Servicios s1=new Servicios("Trivago1234", "Con Acesso", "Todos los dias", "T-12");
        Facturacion f1=new Facturacion(ha1, 20, 600, hu1, s1);
        
        JOptionPane.showMessageDialog(null, 
                "Nombre del huesped"+f1.getHuesped().getNombre()+" "+f1.getHuesped().getApellido()+
                "\nCurp: "+f1.getHuesped().getCurp()+
                "\nClasse de curto: "+f1.getHabitacion().getTipo()+
                "\nPiso:"+f1.getHabitacion().getPiso()+
                "\nNum de cuarto: "+f1.getHabitacion().getNum()+
                "\nCosto del cuarto: "+f1.getHabitacion().getCosto()+
                "\n\n\tSERVICIOS\n"+
                "Contrase�a del wifi: "+f1.getServicio().getWifipass()+
                "\nPisina: "+f1.getServicio().getPisina()+
                "\nFrecuencia de limpieza: "+f1.getServicio().getLimpieza()+
                "\nLugar designado para auto: "+f1.getServicio().getLestacionamiento()+
                "\n\tEmpleados solicitados"+
                "\nNombre: "+e1.getNombre()+
                "\nTrabajo: "+e1.getTrabajo()+
                "\nSueldo: "+e1.getSueldo()+
                "\n\nDescuento: "+f1.getDescuento()+"%"+
                "\nPor Pagar: "+f1.getPagar());

    }

}
