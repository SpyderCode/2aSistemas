package examen_Hotel;

public class Empleados {

    private String nombre;
    private String trabajo;
    private int sueldo;
    
    public Empleados(String nombre,String trabajo,int sueldo) {
        this.nombre=nombre;
        this.trabajo=trabajo;
        this.sueldo=sueldo;
    }
    
    public String getNombre() {
        return nombre;
    }
    public String getTrabajo() {
        return trabajo;
    }
    public int getSueldo() {
        return sueldo;
    }
    
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setTrabajo(String trabajo) {
        this.trabajo=trabajo;
    }
    public void setSueldo(int sueldo) {
        this.sueldo=sueldo;
    }
    
}
