package examen_Hotel;

public class Habitacion {
    private String tipo;
    private int num;
    private int piso;
    private int costo;
   
    
    public Habitacion(String tipo,int num,int piso,int costo) {
        this.tipo=tipo;
        this.num=num;
        this.piso=piso;
        this.costo=costo;
    }
    
    public String getTipo() {
        return tipo;
    }
    public int getNum() {
        return num;
    }
    public int getPiso() {
        return piso;
    }
    public int getCosto() {
        return costo;
    }
    
    public void setTipo() {
        this.tipo=tipo;
    }
    public void setNum() {
        this.num=num;
    }
    public void setPiso() {
        this.piso=piso;
    }
    public void setCosto() {
        this.costo=costo;
    }
}
