package examen_Hotel;

public class Facturacion {
    private Habitacion habitacion;
    private int descuento;
    private int pagar;
    private Huesped huesped;
    private Servicios servicio;
    
    public Facturacion(Habitacion habitacion,int descuento,int pagar,Huesped huesped,Servicios servicio) {
        this.habitacion=habitacion;
        this.descuento=descuento;
        this.pagar=pagar;
        this.huesped=huesped;
        this.servicio=servicio;
    }
    
    public Habitacion getHabitacion() {
        return habitacion;
        
    }
    public int getDescuento() {
        return descuento;
    }
    public int getPagar() {
        return pagar;
    }
    public Huesped getHuesped() {
        return huesped;
    }
    
    public Servicios getServicio() {
        return servicio;
    }
    
    public void setHabitacion(Habitacion habitacion) {
        this.habitacion=habitacion;
    }
    public void setDescuento(int descuento) {
        this.descuento=descuento;
    }
    public void setHuesped(Huesped huesped) {
        this.huesped=huesped;
    }
    public void setServicio(Servicios servicio) {
        this.servicio=servicio;
    }
    public void setPagar(int pagar) {
        this.pagar=pagar;
    }
    
}
