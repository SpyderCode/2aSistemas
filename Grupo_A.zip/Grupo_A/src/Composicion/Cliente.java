package Composicion;

public class Cliente {
    private String id;
    private String nombre;
    private String empresa;
    public Cliente(String id,String nombre,String empresa) {
        this.id=id;
        this.nombre=nombre;
        this.empresa=empresa;
    }
    public String getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getEmpresa() {
        return empresa;
    }
    public void setId(String id) {
        this.id=id;
    }
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setEmpresa(String empresa) {
        this.empresa=empresa;
    }
}
