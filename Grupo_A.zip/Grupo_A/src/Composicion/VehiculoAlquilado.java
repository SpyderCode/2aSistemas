package Composicion;

public class VehiculoAlquilado {
    private Cliente cliente;
    private Vehiculo vehiculo;
    private int dia;
    private String mes;
    private int year;
    private int diasRentado;
    
    public VehiculoAlquilado(Cliente cliente,Vehiculo vehiculo,int dia,String mes,int year,int diasRentado) {
        this.cliente=cliente;
        this.vehiculo=vehiculo;
        this.dia=dia;
        this.mes=mes;
        this.year=year;
        this.diasRentado=diasRentado;
    }
    public Cliente getCliente(){
        return cliente;
    }
    public Vehiculo getVehiculo() {
        return vehiculo;
    }
    public int getDia() {
        return dia;
    }
    public String getMes() {
        return mes;
    }
    public int getYear() {
        return year;
    }
    public int getDiasRentado() {
        return diasRentado;
    }
    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo=vehiculo;
    }
    public void setCliente(Cliente cliente) {
        this.cliente=cliente;
    }
    public void setDia(int dia) {
        this.dia=dia;
    }
    public void setMes(String mes) {
        this.mes=mes;
    }
    public void setYear(int year) {
        this.year=year;
    }
    public void setDiasRentado(int diasRentado) {
        this.diasRentado=diasRentado;
    }
}
