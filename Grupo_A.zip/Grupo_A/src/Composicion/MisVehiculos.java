package Composicion;

import javax.swing.JOptionPane;

public class MisVehiculos {

    public static void main(String[] args) {
       Vehiculo v1=new Vehiculo("ZDF-123-F","Ford","Fiesta"); 
       Cliente c1=new Cliente("C109","Juan Perez","La Corona");
       VehiculoAlquilado a1=new VehiculoAlquilado(c1,v1,21,"Febrero",2018,1);
       JOptionPane.showMessageDialog(null,
               "EL cliente"+c1.getNombre()+"\n"+
       "Con"+c1.getId()+" Rento el vehiculo"+v1.getMarca()+"\n"+
                       "Modelo "+v1.getModelo());
    }

}
