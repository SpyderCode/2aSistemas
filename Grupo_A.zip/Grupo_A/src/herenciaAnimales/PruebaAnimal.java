package herenciaAnimales;

import javax.swing.JOptionPane;

public class PruebaAnimal {

    public static void main(String[] args) {
        Aguila a=new Aguila("Miguel", 30.80, 21, "M", "Bosque", "Grande", "calva", "Grandes", "Amplia");
        Tortuga t=new Tortuga("Jorgito", 50.30, 50, "M", "Mar", "Grande", "Aquatico", 150);
        Delfin d=new Delfin("Flipper", 60.15, 7,"M", "Oceano", "Peces");
        Perro p=new Perro("Arrenita", 8.9, 1, "F", "Casa", "Croquetas", "Arrena");
        
        JOptionPane.showMessageDialog(null, a.toString()+a.cazar()+a.vuela(),"Aguila",JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, t.toString(),"Tortuga",JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, d.toString(),"Delfin",JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, p.toString(),"Arrenita",JOptionPane.INFORMATION_MESSAGE);

    }

}
