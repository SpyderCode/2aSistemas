package herenciaAnimales;

public class Oviparo extends Animal{
    private String tama�o;
    private String especie;
    
    public Oviparo(String nombre,double peso,int edad,String sexo,String habitat,String tama�o,String especie) {
        super(nombre,peso,edad,sexo,habitat);
        this.tama�o=tama�o;
        this.especie=especie;
    }
    
    public String getTama�o() {
        return tama�o;
    }
    public String getEspecie() {
        return especie;
    }
    
    public void setTama�o(String tama�o) {
        this.tama�o=tama�o;
    }
    public void setEspecie(String especie) {
        this.especie=especie;
    }
    
    public String toString() {
        return super.toString()+"\n"+
                "Tama�o: "+this.tama�o+
                "\nEspecie: "+this.especie;
    }
    
    public String ponerHuevos() {
        return "Aqui viene el almuerzo!";
    }
}
