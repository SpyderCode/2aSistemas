package herenciaAnimales;

public class Aguila extends Oviparo{
      private String garras;
      private String vista;
      
      public Aguila(String nombre,double peso,int edad,String sexo,String habitat,String tama�o,String especie,String garras,String vista) {
          super(nombre,peso,edad,sexo,habitat,tama�o,especie);
          this.garras=garras;
          this.vista=vista;
      }
      
      public String getGarras() {
          return garras;
      }
      public String getVista() {
          return vista;
      }
      
      public void setGarras(String garras) {
          this.garras=garras;
      }
      public void setVista(String vista) {
          this.vista=vista;
      }
      
      public String toString() {
          return super.toString()+
                  "\nGarras: "+this.garras+
                  "\nVista: "+this.vista;
      }
      public String vuela() {
          return "El aguila vuela alto";
      }
      public String cazar() {
          return "dun dun duuuuuuun para ese conejito";
      }

}
