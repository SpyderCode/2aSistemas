package herenciaAnimales;

public class Perro extends Mamifero{
    private String colorPelo;
    
    public Perro(String nombre,double peso,int edad,String sexo,String habitat,String alimentacion,String colorPelo) {
        super(nombre, peso, edad, sexo, habitat, alimentacion);
        this.colorPelo=colorPelo;
    }
    
    public String getColorPelo() {
        return colorPelo;
    }
    
    public void setColorPelo(String colorPelo) {
        this.colorPelo=colorPelo;
    }
    
    public String toString() {
        return super.toString()+
                "\ncolorPelo: "+this.colorPelo;
    }
    public String ladra() {
        return "woof woof";
    }
    public String camina() {
        return "el perrillo camina";
    }
    public String correr() {
        return "El perro ya se fue :c";
    }
}
