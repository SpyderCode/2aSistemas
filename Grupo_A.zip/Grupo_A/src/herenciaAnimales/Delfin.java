package herenciaAnimales;

public class Delfin extends Mamifero{
    
    public Delfin(String nombre,double peso,int edad,String sexo,String habitat,String alimentacion) {
        super(nombre,peso,edad,sexo,habitat,alimentacion);
    }
    
    public String nadar() {
        return "El delfin nada en la costa";
    }
    public String saltar() {
        return "EL delfin salta bien musho wuuu";
    }
    
    public String toString() {
        return super.toString();
    }

}
