package herenciaAnimales;

public class Tortuga extends Oviparo{
    private int longevidad;
    
    public Tortuga(String nombre,double peso,int edad,String sexo,String habitat,String tama�o,String especie,int longevidad) {
        super(nombre,peso,edad,sexo,habitat,tama�o,especie);
        this.longevidad=longevidad;
    }
    
    public int getLongevidad() {
        return longevidad;
    }
    
    public void setLongevidad(int longevidad) {
        this.longevidad=longevidad;
    }
    
    public String toString() {
        return super.toString()+
                "\nLongevidad: "+this.longevidad;
    }
    public String come() {
        return "La tortuga come";
    }
    public String camina() {
        return "La tortuga en una semana llega";
    }
    public String nada() {
        return "La tortuga se ahoga";
    }

}
