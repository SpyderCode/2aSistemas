package videoStore;

public class Clientes {
    private String nombre;
    private int edad;
    private String direccion;
    private String id;
    private int telefono;
    private Fecha fecha;
    private Juegos juegos;
    private int days;
    
    public Clientes(String nombre,int edad,String direccion,String id,int telefono,Fecha fecha,Juegos juego,int days) {
        this.nombre=nombre;
        this.edad=edad;
        this.direccion=direccion;
        this.id=id;
        this.telefono=telefono;
        this.fecha=fecha;
        this.juegos=juegos;
        this.days=days;
    }
    
    public String getNombre() {
        return nombre;
    }
    public int getEdad() {
        return edad;
    }
    public String getDireccion() {
        return direccion;
    }
    public String getId() {
        return id;
    }
    public int getTelefono() {
        return telefono;
    }
    public Fecha getFecha() {
        return fecha;
    }
    public Juegos getJuegos() {
        return juegos;
    }
    public int getDays() {
        return days;
    }
    /*
     * METODOS SETS
     */
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setEdad(int edad) {
        this.edad=edad;
    }
    public void setDireccion(String direccion) {
        this.direccion=direccion;
    }
    public void setId(String id) {
        this.id=id;
    }
    public void setTelefono(int telefono) {
        this.telefono=telefono;
    }
    public void setFecha(Fecha fecha) {
        this.fecha=fecha;
    }
    public void setJuegos(Juegos juegos) {
        this.juegos=juegos;
    }
    public void setDays(int days) {
        this.days=days;
    }
    
    public String toString() {
        return "\nNombre: "+getNombre()+
                "\nEdad: "+getEdad()+
                "\nDireccion: "+getDireccion()+
                "\nId: "+getId()+
                "\ntelefono: "+getTelefono()+
                "\nFecha: "+getFecha()+
                "\nJuego: "+getJuegos()+
                "\nDias: "+getDays();
    }
    

}
