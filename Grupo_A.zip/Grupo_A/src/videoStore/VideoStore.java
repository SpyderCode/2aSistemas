package videoStore;

import javax.swing.JOptionPane;

public class VideoStore {

    public static void main(String[] args) {
        Juegos j1=new Juegos("Call of Duty", "Treyarch", "FPS", "+18", 4, "Switch", 30);
        Fecha f1=new Fecha(5, "Marzo", 18);
        Clientes c1=new Clientes("Juan", 19, "Avenida 12", "GG-1213", 312933,f1, j1, 5);
        
        JOptionPane.showMessageDialog(null, c1.toString());

    }

}
