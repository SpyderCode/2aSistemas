package videoStore;

public class Juegos {
private String nombre;
private String desarrollador;
private String categoria;
private String clasificacion;
private int jugadores;
private String tipoConsola;
private double precio;

    public Juegos(String nombre,String desarrollador,String categoria,String clasificacion,int jugadores,String
            tipoConsola,double precio) {
        this.nombre=nombre;
        this.desarrollador=desarrollador;
        this.categoria=categoria;
        this.clasificacion=clasificacion;
        this.jugadores=jugadores;
        this.tipoConsola=tipoConsola;
        this.precio=precio;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDesarrollador() {
        return desarrollador;
    }
    public String getCategoria() {
        return categoria;
    }
    public String getClasificacion() {
        return clasificacion;
    }
    public int getJugadores() {
        return jugadores;
    }
    public String getTipoConsola() {
        return tipoConsola;
    }
    public double getPrecio() {
        return precio;
    }
    
    //Sets
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setDesarrollador(String desarrollador) {
        this.desarrollador=desarrollador;
    }
    public void setCategoria(String categoria) {
        this.categoria=categoria;
    }
    public void setClasificacion(String clasificacion) {
        this.clasificacion=clasificacion;
    }
    public void setJugadores(int jugadores) {
        this.jugadores=jugadores;
    }
    public void setTipoConsola(String tipoConsola) {
        this.tipoConsola=tipoConsola;
    }
    public void setPrecio(double precio) {
        this.precio=precio;
    }
    
    public String toString() {
        return getNombre()+
                "\nDesarrollador: "+getDesarrollador()+
                "\nCategoria: "+getCategoria()+
                "\nClasificacion: "+getClasificacion()+
                "\nJuegadores: "+getJugadores()+
                "\nConsola: "+getTipoConsola()+
                "\nPrecio: "+getPrecio();
    }
}
