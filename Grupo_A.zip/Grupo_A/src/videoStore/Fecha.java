package videoStore;

public class Fecha {
    private int day;
    private String month;
    private int year;
    
    public Fecha(int day,String month,int year) {
        this.day=day;
        this.month=month;
        this.year=year;
        
    }
    
    public int getDay() {
        return day;
    }
    public String getMonth() {
        return month;
    }
    public int getYear() {
        return year;
    }
    
    //sets
    public void setDay(int day) {
        this.day=day;
    }
    public void setMonth(String month) {
        this.month=month;
    }
    public void setYear(int year) {
        this.year=year;
    }
    public String toString() {
        return getDay()+"/"+getMonth()+"/"+getYear();
    }
}
