package banda_de_guerra;

public class Institucion {  
    private String nombre;
    private String direccion;
    private String correo;
    private String telefono;
    private String web;
    private Participante participante;
    
    public Institucion(String nombre,String direccion,String correo,String telefono,String web,Participante participante) {
        this.nombre=nombre;
        this.direccion=direccion;
        this.correo=correo;
        this.telefono=telefono;
        this.web=web;
        this.participante=participante;
    }
    
    /*
     * Los gets
     */
    public String getNombre() {
        return nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public String getCorreo() {
        return correo;
    }
    public String getTelefono() {
        return telefono;
    }
    public String getWeb() {
        return web;
    }
    public Participante participante() {
        return participante;
    }
    
    /*
     * Los Sets
     */
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setDireccion(String direccion) {
        this.direccion=direccion;
    }
    public void setCorreo(String correo) {
        this.correo=correo;
    }
    public void setTelefono(String telefono) {
        this.telefono=telefono;
    }
    public void setWeb(String web) {
        this.web=web;
    }
    public void setParticipante(Participante participante) {
        this.participante=participante;
    }
}
