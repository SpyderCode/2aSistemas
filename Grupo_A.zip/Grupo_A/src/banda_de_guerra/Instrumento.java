package banda_de_guerra;

public class Instrumento {
    private String tipo;
    private String color;
    private double peso;
    private String material;
    private String size;
    
    public Instrumento(String tipo,String color,double peso,String material,String size) {
        this.tipo=tipo;
        this.color=color;
        this.peso=peso;
        this.material=material;
        this.size=size;
    }
    public String getTipo() {
        return tipo;
    }
    public String getColor() {
        return color;
    }
    public double getPeso() {
        return peso;
    }
    public String getMaterial() {
        return material;
    }
    public String getSize() {
        return size;
    }
    
    public void setTipo(String tipo) {
        this.tipo=tipo;
    }
    public void setColor(String color) {
        this.color=color;
    }
    public void setPeso(int peso) {
        this.peso=peso;
    }
    public void setMaterial(String material) {
        this.material=material;
    }
    public void setSize(String size) {
        this.size=size;
    }
    
    public String toString() {
        return "\nTipo: "+getTipo()+
                "\ncolor: "+getColor()+
                "\npeso: "+getPeso()+
                "\nMaterial: "+getMaterial()+
                "\nSize: "+getSize();
    }
}
