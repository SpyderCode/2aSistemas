package banda_de_guerra;

public class Participante {
    private String nombre;
    private String carrera;
    private String sexo;
    private String tsangre;
    private String correo;
    private String direccion;
    private int edad;
    private double estatura;
    private double peso;
    private Instrumento instrumento;
    
    public Participante(String nombre,String carrera,String sexo,String tsangre,String correo,String direccion
            ,int edad,double estatura,double peso,Instrumento instrumento) {
        this.nombre=nombre;
        this.carrera=carrera;
        this.sexo=sexo;
        this.tsangre=tsangre;
        this.correo=correo;
        this.direccion=direccion;
        this.edad=edad;
        this.estatura=estatura;
        this.peso=peso;
        this.instrumento=instrumento;
    }
    
    public String getNombre() {
        return nombre;
    }
    public String getCarrera() {
        return carrera;
    }
    public String getSexo() {
        return sexo;// 7u7
    }
    public String getTsangre() {
        return tsangre;
    }
    public String getCorreo() {
        return correo;
    }
    public String getDireccion() {
        return direccion;
    }
    public int getEdad() {
        return edad;
    }
    public double getEstatura() {
        return estatura;
    }
    public double getPeso() {
        return peso;
    }
    public Instrumento getInstrumento() {
        return instrumento;
    }
    
    /*
     * Los Sets
     */
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setCarrera(String carrera) {
        this.carrera=carrera;
    }
    public void setSexo(String sexo) {
        //you and me baby 7u7
        this.sexo=sexo;
    }
    public void setTsangre(String tsangre) {
        this.tsangre=tsangre;
    }
    public void setCorreo(String correo) {
        this.tsangre=tsangre;
    }
    public void setDireccion(String direccion) {
        this.direccion=direccion;
    }
    public void setEdad(int edad) {
        this.edad=edad;
    }
    public void setEstatura(double estatura) {
        this.estatura=estatura;
    }
    public void setPeso(double peso) {
        this.peso=peso;
    }
    public void setInstrumento(Instrumento instrumento) {
        this.instrumento=instrumento;
    }
    
    public String toString() {
        return "No";
    }
}
