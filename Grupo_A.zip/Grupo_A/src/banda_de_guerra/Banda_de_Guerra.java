package banda_de_guerra;

import javax.swing.JOptionPane;

public class Banda_de_Guerra {

    public static void main(String[] args) {
        Instrumento i1=new Instrumento("Guitarra", "Rojo", 2, "Titanio", "Venti");
        Participante p1=new Participante("Juan", "Musica", "Masculino", "AB+", "Juan@Juan.juan.mx", "Calle 12", 17, 1.80, 80, i1);
        Institucion in1=new Institucion("ITZLMN", "Calle 120", "ITZ@ITZ.kr", "342-342-1233", "ITZ.kr.mx.eu.ru.mx", p1);
        
        JOptionPane.showMessageDialog(null, i1);

    }

}
