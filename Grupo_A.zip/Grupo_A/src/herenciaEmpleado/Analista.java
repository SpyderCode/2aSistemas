package herenciaEmpleado;

public class Analista {

}
