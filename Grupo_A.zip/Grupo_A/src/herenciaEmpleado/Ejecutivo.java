package herenciaEmpleado;

public class Ejecutivo extends Director{
    private double comision;
    public Ejecutivo(String id,String nombre,String apellido,int edad,String sexo,String direccion,double sueldo,String Explaboral,String puesto,double comision) {
    super(id,nombre,apellido,edad,sexo,direccion,sueldo,Explaboral,puesto);
    this.comision=comision;
    }
    
    public double getComision() {
        return comision;
    }
    
    public void setComision(double comision) {
        this.comision=comision;
    }
    
    public String toString() {
        return super.toString()+
                "\nComision y sueldo"+(this.comision+this.getSueldo());
    }
}
