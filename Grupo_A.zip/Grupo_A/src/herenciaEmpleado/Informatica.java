package herenciaEmpleado;

public class Informatica extends Empleado{
    public String area;
    public String especializacion;
    
    public Informatica(String id,String nombre,String apellido,int edad,String sexo,String direccion,double sueldo,String area,String especializacion) {
        super(id,nombre,apellido,edad,sexo,direccion,sueldo);
        this.area=area;
        this.especializacion=especializacion;
    }
}
