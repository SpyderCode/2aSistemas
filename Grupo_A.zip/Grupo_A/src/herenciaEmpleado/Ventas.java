package herenciaEmpleado;

public class Ventas extends Comercial{
    private String horario;
    private int Nclientes;
    public Ventas(String id,String nombre,String apellido,int edad,String sexo,String direccion,double sueldo,String sucursal,String horario,int Nclientes) {
        super(id,nombre,apellido,edad,sexo,direccion,sueldo,sucursal);
        this.horario=horario;
        this.Nclientes=Nclientes;
        
    }
    public String getHorario() {
        return horario;
    }
    public int getNclientes() {
        return Nclientes;
    }
    
    public void setHorario(String horario) {
        this.horario=horario;
    }
    public void setNclientes(int Nclientes) {
        this.Nclientes=Nclientes;
    }
    
    public String toString() {
        return super.toString()+
                "\nHorario: "+this.horario+
                "\nNum de clientes: "+this.Nclientes;
    }
}

