package herenciaEmpleado;

public class Empleado {
    private String id;
    private String nombre;
    private String apellido;
    private int edad;
    private String sexo;
    private String direccion;
    private double sueldo;

    public Empleado(String id,String nombre,String apellido,int edad,String sexo,String direccion,double sueldo) {
    this.id=id;
    this.nombre=nombre;
    this.apellido=apellido;
    this.edad=edad;
    this.sexo=sexo;
    this.direccion=direccion;
    this.sueldo=sueldo;
    }
    
    public String getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public int getEdad() {
        return edad;
    }
    public String getSexo() {
        return sexo;
    }
    public String getDireccion() {
        return direccion;
    }
    public double getSueldo() {
        return sueldo;
    }
    
    public void setId(String id) {
        this.id=id;
    }
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setApellido(String apellido) {
        this.apellido=apellido;
    }
    public void setEdad(int edad) {
        this.edad=edad;
    }
    public void setSexo(String sexo) {
        this.sexo=sexo;
    }
    public void setDireccion(String direccion) {
        this.direccion=dirrecion;
    }
    public void setSueldo(double sueldo) {
        this.sueldo=sueldo;
    }
    
    public String toString() {
        return "Id: "+this.id+
                "\nNombre: "+this.nombre+" "+this.apellido+
                "\nEdad: "+this.edad+
                "\nSexo: "+this.sexo+
                "\nDireccion: "+this.direccion+
                "\nSueldo: "+this.sueldo;
    }
}
