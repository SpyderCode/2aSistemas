package herenciaEmpleado;

public class Director extends Empleado{
    private String Explaboral;
    private String puesto;
    
    public Director(String id,String nombre,String apellido,int edad,String sexo,String direccion,double sueldo,String Explaboral,String puesto) {
        super(id,nombre,apellido,edad,sexo,direccion,sueldo);
        this.Explaboral=Explaboral;
        this.puesto=puesto;
    }
    public String getExplaboral() {
        return Explaboral;
    }
    public String getPuesto() {
        return puesto;
    }
    
    public void setExplaboral(String Explaboral) {
        this.Explaboral=Explaboral;
    }
    public void setPuesto(String puesto) {
        this.puesto=puesto;
    }
    
    public String toString() {
        return super.toString()+
                "\nExperiencia Laboral: "+this.Explaboral+
                "\nPUesto: "+this.puesto;
    }
}
