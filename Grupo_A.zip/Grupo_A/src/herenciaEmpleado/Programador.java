package herenciaEmpleado;

public class Programador {

}
