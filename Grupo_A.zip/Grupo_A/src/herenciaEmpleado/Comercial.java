package herenciaEmpleado;

public class Comercial extends Empleado{
    private String sucursal;
    
    public Comercial(String id,String nombre,String apellido,int edad,String sexo,String direccion,double sueldo,String sucursal) {
        super(id,nombre,apellido,edad,sexo,direccion,sueldo);
        this.sucursal=sucursal;
    }
    public String getSucursal() {
        return sucursal;
    }
    public void setSucursal(String sucursal) {
        this.sucursal=sucursal;
    }
    public String toString() {
        return super.toString()+
                "\nSucursal: "+this.sucursal;
    }
    
}
