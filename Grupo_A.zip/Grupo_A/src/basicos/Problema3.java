package basicos;

import javax.swing.JOptionPane;

public class Problema3 {
	public void problema3() {
	String nombre;
	float kilo,libra,metros,pulgadas;
	nombre=JOptionPane.showInputDialog("Ingrese su nombre");
	kilo=Float.parseFloat(JOptionPane.showInputDialog("Ingrese su peso en Kg"));
	metros=Float.parseFloat(JOptionPane.showInputDialog("Ingrese su altura en metros"));
	libra=(float) (kilo*2.204623);
	pulgadas=(float) (metros*39.3707);
	JOptionPane.showMessageDialog(null, "Hola "+nombre+"\nSu peso es de: "+kilo+"Kg\t\t"+libra+"Lbs\nSu altura es: "
			+ metros+"mts\t\t"+pulgadas+"in");
	
	}
}
