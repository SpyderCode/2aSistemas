package basicos;

import javax.swing.JOptionPane;

public class Problema2 {
	public void problema2() {
		float r,x,y;
		x=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de x"));
		y=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de y"));
		r=(float) (Math.pow(x, y+5)-((Math.pow(y+4*x*y, 1/2)/Math.abs(x-y))));
		JOptionPane.showMessageDialog(null, "El resultado es "+r);
	}
}
