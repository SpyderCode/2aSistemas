package basicos;

public class pruebaProblema {

	public static void main(String[] args) {
		menuProblema mp=new menuProblema();
		mp.menu();

	}

}
