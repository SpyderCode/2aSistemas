package basicos;

import javax.swing.JOptionPane;

public class menuDivisas {
	public void menu() {
		int opc;
		divisas d = new divisas();
		do {
		opc=Integer.parseInt(JOptionPane.showInputDialog("~~Selecione uno~~\n1.-dolares a peso\n2.-peso a dolares\n"
				+ "3.-euros a dolares\n4.-dolares a euros\n5.-euros a pesos\n6.-pesos a euros\n"
				+ "7.-peso colombiano a peso"
				+ "\n8.-peso a peso colombiano\n9.-dolares a peso colombiano\n10.peso colombiano a dolares"
				+ "\n11.-dolar a yen\n12.-yen a dolar\n13.-Salir"));
		switch (opc) {
		case 1:d.pesodollar();
			break;
		case 2:d.dollarpeso();
			break;
		case 3:d.dollareuro();
			break;
		case 4:d.eurodollar();
			break;
		case 5:d.pesoeuro();
			break;
		case 6:d.europeso();
			break;
		case 7:d.pesocolombia();
			break;
		case 8:d.colombiapeso();
			break;
		case 9:d.colombiadollar();
			break;
		case 10:d.dollarcolombia();
			break;
		case 11:d.yendollar();
			break;
		case 12:d.dollaryen();
			break;
		case 13:System.exit(0);
			break;
		default:JOptionPane.showMessageDialog(null, "ERROR");
			break;
			}
		}while(opc!=13);
		
	}
}
