package basicos;

import javax.swing.JOptionPane;

public class menuSaludo {
public void menu() {
	saludo s =new saludo();
	String opc;
	int OPC;
	do {
	opc=JOptionPane.showInputDialog(null,"1.-Espa�ol\n2.-Ingles\n3.-Frances\n4.-Salir","Menu Saludo",JOptionPane.INFORMATION_MESSAGE);
	OPC=Integer.parseInt(opc);
	switch(OPC) {
	case 1:s.bienvenido();
		break;
	case 2:s.welcome();
		break;
	case 3:s.benvenuti();
		break;
	case 4:System.exit(0);
		break;
		default:JOptionPane.showMessageDialog(null, "ERROR","ERROR",JOptionPane.ERROR_MESSAGE);
	}//fin de switch
	}while(OPC!=4);//fin de do while
	}//fin de menu()
}
