package basicos;

import javax.swing.JOptionPane;

public class menuProblema {
	public void menu() {
		Problema1 pu=new Problema1();
		Problema2 pd=new Problema2();
		Problema3 pt=new Problema3();
		Problema4 pq=new Problema4();
		Problema5 pc=new Problema5();
		String opc;
		int OPC;
		do {
		opc=JOptionPane.showInputDialog(null,"1.-Problema 1\n2.-Problema 2\n3.-Problema 3\n4.-Problema 4\n5.-Problema 5\n"
				+ "6.-Salir");
		OPC=Integer.parseInt(opc);
		switch(OPC) {
		case 1:pu.problema();
			break;
		case 2:pd.problema2();
			break;
		case 3:pt.problema3();
			break;
		case 4:pq.problema4();
			break;
		case 5:pc.problema5();
			break;
		case 6:System.exit(0);
			break;
			default:JOptionPane.showMessageDialog(null, "ERROR","ERROR",JOptionPane.ERROR_MESSAGE);
		}//fin de switch
		}while(OPC!=6);//fin de do while
	}
}
