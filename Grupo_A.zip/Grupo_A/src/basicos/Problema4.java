package basicos;

import javax.swing.JOptionPane;

public class Problema4 {
	public void problema4() {
		float a,b,x;
		a=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de a"));
		b=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de b"));
		x=(float) ((Math.pow(a+b, 2))/3);
		JOptionPane.showMessageDialog(null, "El resultado es "+x);
	}
}
