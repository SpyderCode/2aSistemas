package basicos;

public class prubeaSaludo {

	public static void main(String[] args) {
		//crear objeto de la clase menuSaludo
		menuSaludo r=new menuSaludo();
		r.menu();

	}

}
