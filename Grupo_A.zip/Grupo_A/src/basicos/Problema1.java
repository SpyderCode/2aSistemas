package basicos;

import javax.swing.JOptionPane;

public class Problema1 {
	public void problema() {
		float c,b,a;
		a=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de a"));
		b=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de b"));
		c=(float)(67*b-(-(a*b)*(1/(a-b+(4*a*b)))+23*a));
		JOptionPane.showMessageDialog(null, "El valor de C es "+c);
		}
}
