package basicos;

public class pruebaFiguras {

	public static void main(String[] args) {
		menuFiguras mf = new menuFiguras();
		mf.menuPrincipal();

	}

}
