package basicos;

import javax.swing.JOptionPane;

public class Imc {
	public void Indice() {
		float peso, altura, imc;
		String nombre;
		nombre = JOptionPane.showInputDialog("Como se llama?");
		peso = Float.parseFloat(JOptionPane.showInputDialog(null, "Ingrese su peso"));
		altura = Float.parseFloat(JOptionPane.showInputDialog(null, "Ingrese su altura"));

		imc = (float) (peso / (Math.pow(altura, 2)));
		if (imc <= 18.5)
			JOptionPane.showMessageDialog(null, nombre + " su Imc es de " + imc + "\nEsta bajo peso, come mas");
		else if (18.5 < imc && imc <= 24.9)
			JOptionPane.showMessageDialog(null, nombre + " su Imc es de " + imc + "\nSu peso es normal, bien hecho!");
		else if (24.9 < imc && imc <= 29.9)
			JOptionPane.showMessageDialog(null,
					nombre + " su Imc es de " + imc + "\nEsta sobrepeso, haga poco ejercicio");
		else
			JOptionPane.showMessageDialog(null, nombre + " su Imc es de " + imc + "\nEs obeso, consulte un medico");
	}
}
