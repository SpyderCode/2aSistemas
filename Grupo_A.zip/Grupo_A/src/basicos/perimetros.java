package basicos;

import javax.swing.JOptionPane;

public class perimetros {
	public void circulo() {
		double radio,peri;
		radio=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor del radio"));
		peri=Math.PI*2*radio;
		JOptionPane.showMessageDialog(null, "Perimetro del circulo = "+peri);
		
	}
	public void triangulo() {
		double lado1,lado2,lado3,peri;
		lado1=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor del lado 1"));
		lado2=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor del lado 2"));
		lado3=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor del lado 3"));
		peri=lado1+lado2+lado3;
		JOptionPane.showMessageDialog(null, "Perimetro del triangulo = "+peri);
	}
	public void rectangulo() {
		double base,altura,peri;
		base=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingresa el valor de la base"));
		altura=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor de la altura"));
		peri=(2*base+2*altura);
		JOptionPane.showMessageDialog(null, "Perimetro del rectangulo = "+peri);
	}
}
