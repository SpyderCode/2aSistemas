package basicos;

import javax.swing.JOptionPane;

public class menuFiguras {
	public void menuPrincipal() {
		int opc;
		menuFiguras mf=new menuFiguras();
		do {
		opc=Integer.parseInt(JOptionPane.showInputDialog("1.-Areas\n2.-Perimetros\n3.-Salir"));
		switch(opc) {
		case 1:mf.menuAreas();
			break;
		case 2:mf.menuPerimetros();
			break;
		case 3:System.exit(0);
			break;
		default:JOptionPane.showMessageDialog(null, "ERROR");
			break;
			}//fin de switch
		}while(opc!=3);
	}
	public void menuAreas() {
		int opc;
		areas a=new areas();//declaracion del objeto
		menuFiguras mf=new menuFiguras();
		do {
		opc=Integer.parseInt(JOptionPane.showInputDialog("1.-circulo\n2.-Triangulo\n3.-Rectangulo\n4.-Regresar"));
		switch(opc) {
		case 1:a.circulo();
			break;
		case 2:a.triangulo();
			break;
		case 3:a.rectangulo();
			break;
		case 4:mf.menuPrincipal();
			break;
		default:JOptionPane.showMessageDialog(null, "ERROR");
			break;
			}//fin de switch
		}while(opc!=4);
		
	}
	public void menuPerimetros() {
		int opc;
		perimetros p=new perimetros();//declaracion de objeto
		menuFiguras mf=new menuFiguras();
		do {
		opc=Integer.parseInt(JOptionPane.showInputDialog("1.-circulo\n2.-Triangulo\n3.-Rectangulo\n4.-Regresar"));
		switch(opc) {
		case 1:p.circulo();
			break;
		case 2:p.triangulo();
			break;
		case 3:p.rectangulo();
			break;
		case 4:mf.menuPrincipal();
			break;
		default:JOptionPane.showMessageDialog(null, "ERROR");
			break;
			}//fin de switch
		}while(opc!=4);
	}

}
