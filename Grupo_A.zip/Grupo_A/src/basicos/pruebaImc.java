package basicos;

public class pruebaImc {

	public static void main(String[] args) {
		Imc i=new Imc();
		i.Indice();

	}

}
