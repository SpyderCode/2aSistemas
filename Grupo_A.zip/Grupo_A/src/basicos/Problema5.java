package basicos;

import javax.swing.JOptionPane;

public class Problema5 {
	public void problema5() {
		float a,b,x;
		a=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de a"));
		b=Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de b"));
		x=a;
		a=b;
		b=x;
		JOptionPane.showMessageDialog(null, "a es "+a+"\nb es "+b);
	}
}
