package basicos;

import javax.swing.JOptionPane;

public class areas {
	public void circulo() {
		double radio, area;
		radio = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingresa valor del Radio"));
		area = Math.PI * Math.pow(radio, 2);
		JOptionPane.showMessageDialog(null, "Area del Circulo=" + area, "Area del circulo", JOptionPane.DEFAULT_OPTION);
	}

	public void triangulo() {
		double base,altura,area;
		base=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingresa el valor de la base"));
		altura=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor de la altura"));
		area=(base*altura)/2;
		JOptionPane.showMessageDialog(null, "Area del triangulo="+area);
	}

	public void rectangulo() {
		double base,altura,area;
		base=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingresa el valor de la base"));
		altura=Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el valor de la altura"));
		area=(base*altura);
		JOptionPane.showMessageDialog(null, "Area del rectangulo="+area);

	}
}
