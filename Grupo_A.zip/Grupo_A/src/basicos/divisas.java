package basicos;

import javax.swing.JOptionPane;

public class divisas {
	public void pesodollar() {
		float peso,dollar;
		dollar=Float.parseFloat(JOptionPane.showInputDialog("Cuantos dollares quiere?"));
		peso =(float) ((float) dollar*18.55);
		JOptionPane.showMessageDialog(null, "Debe pagar "+peso+" pesos");
	}
	public void dollarpeso() {
		float peso,dollar;
		peso=Float.parseFloat(JOptionPane.showInputDialog("Cuantos pesos quiere?"));
		dollar=(float) (peso/18.55);
		JOptionPane.showMessageDialog(null, "Debe pagar "+dollar+" dollares");
	}
	public void dollareuro() {
		float euro,dollar;
		euro=Float.parseFloat(JOptionPane.showInputDialog("Cuantos euros quiere?"));
		dollar=(float) (euro/.8);
		JOptionPane.showMessageDialog(null, "Debe pagar "+dollar+" dollares");
	}
	public void eurodollar() {
		float euro,dollar;
		dollar=Float.parseFloat(JOptionPane.showInputDialog("Cuantos dollares quiere?"));
		euro =(float) ((float) dollar*.8);
		JOptionPane.showMessageDialog(null, "Debe pagar "+euro+" euros");
	}
	public void pesoeuro() {
		float euro,pesos;
		euro=Float.parseFloat(JOptionPane.showInputDialog("Cuantos euros quiere?"));
		pesos=(float) (euro/.04);
		JOptionPane.showMessageDialog(null, "Debe pagar "+pesos+" pesos");
	}
	public void europeso() {
		float euro,pesos;
		pesos=Float.parseFloat(JOptionPane.showInputDialog("Cuantos pesos quiere?"));
		euro =(float) ((float) pesos*.04);
		JOptionPane.showMessageDialog(null, "Debe pagar "+euro+" euros");
	}
	public void pesocolombia() {
		float col,pesos;
		col=Float.parseFloat(JOptionPane.showInputDialog("Cuantos pesos colombianos quiere?"));
		pesos=(float) (col*.006);
		JOptionPane.showMessageDialog(null, "Debe pagar "+pesos+"pesos");
	}
	public void colombiapeso() {
		float col,pesos;
		pesos=Float.parseFloat(JOptionPane.showInputDialog("Cuantos pesos quiere?"));
		col=(float) (pesos/.006);
		JOptionPane.showMessageDialog(null, "Debe pagar "+col+"pesos colombia");
	}
	public void colombiadollar() {
		float col,dollar;
		dollar=Float.parseFloat(JOptionPane.showInputDialog("Cuantos dolares quiere?"));
		col=(float) (dollar/.00036);
		JOptionPane.showMessageDialog(null, "Debe pagar "+col+"pesos colombia");
	}
	public void dollarcolombia() {
		float col,dollar;
		col=Float.parseFloat(JOptionPane.showInputDialog("Cuantos pesos colombianos quiere?"));
		dollar=(float) (col*.00036);
		JOptionPane.showMessageDialog(null, "Debe pagar "+dollar+" dollares");
	}
	public void yendollar() {
		float yen,dollar;
		dollar=Float.parseFloat(JOptionPane.showInputDialog("Cuantos dolares quiere?"));
		yen=(float) (dollar/.009);
		JOptionPane.showMessageDialog(null, "Debe pagar "+yen+" yen");
	}
	public void dollaryen() {
		float yen,dollar;
		yen=Float.parseFloat(JOptionPane.showInputDialog("Cuantos yens quiere?"));
		dollar=(float) (yen*.009);
		JOptionPane.showMessageDialog(null, "Debe pagar "+dollar+" dollares");
	}

}
