package basicos;

import javax.swing.JOptionPane;

public class saludo {
	public void bienvenido() {
		JOptionPane.showMessageDialog(null, "Bienvenido al ITZ!!!");
	}
	public void benvenuti() {
		JOptionPane.showMessageDialog(null, "Benvenuti ITZ!!!");
	}
	public void welcome() {
		JOptionPane.showMessageDialog(null, "Welcome to the ITZ!!!");
	}
}
