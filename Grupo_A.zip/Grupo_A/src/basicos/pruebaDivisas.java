package basicos;

public class pruebaDivisas {

	public static void main(String[] args) {
		//crear el objeto pruebaDivisas
		menuDivisas md =new menuDivisas();
		md.menu();
	}

}
