package arreglos;

public class PruebaArregloejemplo {

    public static void main(String[] args) {
        Arreglo a=new Arreglo();
        a.promedio();

    }

}
