package arreglos;

import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class ecuacion {
	public void ecuacion() {
		Random nr = new Random();
		JTextArea salida = new JTextArea();
		String result = "x\ty\tx2\ty2\tx2y\tx2y2\tx-y\txy2\tx2-y\n";
		int a, b, c, z;
		int sumx = 0, sumy = 0, sumx2 = 0, sumx2y = 0, sumy2 = 0, sumx2y2 = 0, sumxry = 0, sumxy2 = 0, sumx2ry = 0;
		Integer x[] = new Integer[10];
		Integer y[] = new Integer[10];
		Integer x2[] = new Integer[10];
		Integer x2y[] = new Integer[10];
		Integer y2[] = new Integer[10];
		Integer x2y2[] = new Integer[10];
		Integer xry[] = new Integer[10];// x resta y
		Integer xy2[] = new Integer[10];
		Integer x2ry[] = new Integer[10];

		for (int i = 0; i < x.length; i++) {
			x[i] = nr.nextInt(10) + 1;
			y[i] = nr.nextInt(10) + 1;
		} // fin del for
		for (int i = 0; i < x.length; i++) {
			x2[i] = (int) Math.pow(x[i], 2);
			x2y[i] = (int) (Math.pow(x[i], 2) * y[i]);
			y2[i] = (int) Math.pow(y[i], 2);
			x2y2[i] = x2[i] * y2[i];
			xry[i] = x[i] - y[i];
			xy2[i] = (int) (x[i] * Math.pow(y[i], 2));
			x2ry[i] = x2[i] - y[i];
		} // fin del for

		for (int i = 0; i < x.length; i++) {// sumatorias
			sumx += x[i];
			sumy += y[i];
			sumx2 += x2y[i];
			sumy2 += y2[i];
			sumx2y2 += x2y2[i];
			sumxry += xry[i];
			sumxy2 += xy2[i];
			sumx2ry += x2ry[i];
		} // fin del for te sumatorias

		a = sumx2 + sumx2y - sumy2;
		b = sumx2y2 + sumxry + a;
		c = sumxy2 + sumx2ry + a - b;
		z = a + b - c;

		for (int i = 0; i < x.length; i++) {
			result += x[i] + "\t" + y[i] + "\t" + x2[i] + "\t" + y2[i] + "\t" + x2y[i] + "\t" + x2y2[i] + "\t" + xry[i]
					+ "\t" + xy2[i] + "\t" + x2ry[i] + "\n";
		} // fin del for
		result += sumx + "\t" + sumy + "\t" + sumx2 + "\t" + sumy2 + "\t" + sumx2y + "\t" + sumx2y2 + "\t" + sumxry
				+ "\t" + sumxy2 + "\t" + sumx2ry + "\n";
		result += "\n\t\t" + "z=" + z + "=" + a + "+" + b + "-" + c;

		salida.setText(result);
		JOptionPane.showMessageDialog(salida, salida, "Quiero Dormir", JOptionPane.DEFAULT_OPTION);

	}
}
