package arreglos;

public class pruebaEcuacion {

	public static void main(String[] args) {
		ecuacion e=new ecuacion();
		e.ecuacion();

	}

}
