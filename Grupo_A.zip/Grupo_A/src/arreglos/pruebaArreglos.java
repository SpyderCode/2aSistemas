package arreglos;

public class pruebaArreglos {

	public static void main(String[] args) {
		menuArreglos m= new menuArreglos();
		m.menu();
		

	}

}
