package arreglos;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class sumaArreglos {
	public void suma() {
		Random nr=new Random();
		JTextArea salida=new JTextArea();
		int i;
		String result="Arr 1\tArr 2\tSuma\n";
		//Declaracion de los arreglos a,b,c
		Integer a[]=new Integer[10];
		Integer b[]=new Integer[10];
		Integer c[]=new Integer[10];
		//Inicializamos los arreglos a,b
		for(i=0;i<a.length;i++) {
			a[i]=nr.nextInt(10)+1;
			b[i]=nr.nextInt(10)+1;
		}//fin del for
		//suma valores de los arreglos a,b
		for(i=0;i<a.length;i++) 
			c[i]=a[i]+b[i];
		
		//concatenar los arreglos a,b,c
		for(i=0;i<a.length;i++)
		result+=a[i]+"\t"+b[i]+"\t"+c[i]+"\n";
		
		//mostrar los datos
		salida.setText(result);
		JOptionPane.showMessageDialog(salida, salida,"Suma de arreglos",JOptionPane.DEFAULT_OPTION);
		
	}
}
