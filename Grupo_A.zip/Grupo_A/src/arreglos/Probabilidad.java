package arreglos;

public class Probabilidad {

    public static void main(String[] args) {
       int[] calif= {25,25,30,31,34,35,35,35,36,37,37,39,41,43,48,50,52,52,53,54,56,56,60,66,70,84};
       int sumx=0;//sumatorias
       /*media = x-*/
       int media,rango;//ecuaciones
       for(int i=0;i<calif.length;i++) {
           sumx+=calif[i];
       }//fin del for
       media=sumx/calif.length;
       rango=calif[calif.length-1]-calif[0];
       
       for(int i=0;i<calif.length;i++) {
           
       }
    }

}
