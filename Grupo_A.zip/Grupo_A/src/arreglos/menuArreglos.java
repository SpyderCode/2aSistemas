package arreglos;

import javax.swing.JOptionPane;

public class menuArreglos {
public void menu() {
	sumaArreglos s=new sumaArreglos();
	restaArreglos r=new restaArreglos();
	mulArreglos m=new mulArreglos();
	int OPC;
	do {
		OPC=Integer.parseInt(JOptionPane.showInputDialog(null,"1.-suma\n2.-resta\n3.-multiplicacion\n"
			+ "4.-Salir"));
	switch(OPC) {
	case 1:s.suma();
		break;
	case 2:r.resta();
		break;
	case 3:m.multiplica();
		break;
	case 4:System.exit(0);
		break;
		default:JOptionPane.showMessageDialog(null, "ERROR","ERROR",JOptionPane.ERROR_MESSAGE);
	}//fin de switch
	}while(OPC!=6);//fin de do while
}
}
