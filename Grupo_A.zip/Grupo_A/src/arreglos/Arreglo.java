package arreglos;

import javax.swing.JOptionPane;

public class Arreglo {
    public void promedio(){
    String nombre;
    int i;
    double promedio=0;
    int arreglo[] = new int[5];
    String cadena[]=new String[5];
    nombre= JOptionPane.showInputDialog("Ingrese el nombre del alumno");
    for(i=0;i<arreglo.length;i++) {
    cadena[i]=JOptionPane.showInputDialog("Ingresa Nombre de la materia");
    arreglo[i]=Integer.parseInt(JOptionPane.showInputDialog("Ingresa la calificacion para la materia: "+ cadena[i]));
        }//fin del for
    for(i=0;i<arreglo.length;i++)
        promedio+=arreglo[i];
    
    JOptionPane.showMessageDialog(null,"Alumno: "+nombre+"\n"+"_____________________\n"+
        cadena[0]+"\t\t"+arreglo[0]+"\n"+
        cadena[1]+"\t\t"+arreglo[1]+"\n"+
        cadena[2]+"\t\t"+arreglo[2]+"\n"+
        cadena[3]+"\t\t"+arreglo[3]+"\n"+
        cadena[4]+"\t\t"+arreglo[4]+"\n"+
        "____________________________\n"+
        "Promedio="+promedio/arreglo.length);
    }
}
