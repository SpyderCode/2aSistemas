package constructores;

public class Vehiculo {
    String matricula;
    String marca;
    String modelo;
    String color;
    double tarifa;
    boolean disponible;
    
    //declarar el constructor de la clase
    public Vehiculo(String matricula,String marca,String modelo,String color, double tarifa) {
        this.matricula=matricula;
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
        this.tarifa=tarifa;
    }
    /* Declara los metodos get y set
     * Sintaxis del metodo get
     * public tipo_dato_atriburo_getNombreAtributo(){
     * return Nombre Atributo
     * }*/
    public String getMatricula() {
        return matricula;
    }
    public String getMarca() {
        return marca;
    }
    public String getModelo() {
        return modelo;
    }
    public String getColor() {
        return color;
    }
    public double getTarifa() {
        return tarifa;
    }
    public String toString() {
        String info;
        info="Matricula: "+getMatricula()+
                "\nMarca: "+getMarca()+"\n"+
                "Modelo: "+getModelo()+"\n"+
                "Color: "+getColor()+"\n"+
                "Tarifa: "+getTarifa();
        return info;
    }
    
}
