package constructores;

import javax.swing.JOptionPane;

public class PruebaEstudiante {

    public static void main(String[] args) {
     Estudiante e1=new Estudiante("Joel","Ramirez",21,"17450765","Arquitectura"
             ,"Tercer",80.5,"Jramirez@gmail.com","ITZ","Masculino",492123457,
             "Avenida juarez 123");
     JOptionPane.showMessageDialog(null, e1.toString(),"Datos del Estudiante",JOptionPane.INFORMATION_MESSAGE);
     e1.setNombre("Jesus");
     e1.setEdad(22);
     JOptionPane.showMessageDialog(null, e1.toString(),"Datos del Estudiante",JOptionPane.INFORMATION_MESSAGE);
    }

}
