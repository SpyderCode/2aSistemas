package constructores;

public class Fabrica {
    private String nombre,direccion,giro,horario,sitioWeb,correo,registro;
    private int numeroTrabajadores;
    private Integer telefono;
    private double produccion;
    
    //constructor
    public Fabrica(String nombre,String direccion,String giro,int numeroTrabajadores,Integer telefono,String horario
            ,String sitioWeb,String correo,String registro,double produccion) {
        this.nombre=nombre;
        this.direccion=direccion;
        this.giro=giro;
        this.numeroTrabajadores=numeroTrabajadores;
        this.telefono=telefono;
        this.horario=horario;
        this.sitioWeb=sitioWeb;
        this.correo=correo;
        this.registro=registro;
        this.produccion=produccion; 
    }
    public String getNombre() {
        return nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public String getGiro() {
        return giro;
    }
    public int getNumeroTrabajadores() {
        return numeroTrabajadores;
    }
    public Integer getTelefono() {
        return telefono;
    }
    public String getHorario() {
        return horario;
    }
    public String getSitioWeb() {
        return sitioWeb;
    }
    public String getCorreo() {
        return correo;
    }
    public String getRegistro() {
        return registro;
    }
    public double getProduccion() {
        return produccion;
    }
    
    //metodos Sets
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setTelefono(Integer telefono) {
        this.telefono=telefono;
    }
    public void setDireccion(String direccion) {
        this.direccion=direccion;
    }
    //Muestra los datos
    public String toString() {
        return "Nombre: "+getNombre()+
                "\nDireccion: "+getDireccion()+
                "\nGiro: "+getGiro()+
                "\nNumero de Trabajadores: "+getNumeroTrabajadores()+
                "\nTelefono: "+getTelefono()+
                "\nhorario: "+getHorario()+
                "\nSitio Web: "+getSitioWeb()+
                "\nCorreo: "+getCorreo()+
                "\nRegistro: "+getRegistro()+
                "\nProduccion: "+getProduccion();
}}
