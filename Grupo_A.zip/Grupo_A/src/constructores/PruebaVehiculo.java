package constructores;

import javax.swing.JOptionPane;

public class PruebaVehiculo {

    public static void main(String[] args) {
        Vehiculo v1=new Vehiculo("ZFA 123","Chevrolet","Chevy","Gris",100.20);
        Vehiculo v2=new Vehiculo("ZFE 321","Dodge","Cirrus","Negro",567.60);
        JOptionPane.showMessageDialog(null,v1.toString(),"Datos del Vehiculo",JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null,v2.toString(),"Datos del Vehiculo 2",JOptionPane.INFORMATION_MESSAGE);

    }

}
