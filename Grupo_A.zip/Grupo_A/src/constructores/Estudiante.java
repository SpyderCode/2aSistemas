package constructores;

public class Estudiante {
    private String nombre;
    private String apellido;
    private int edad;
    private String matricula;
    private String carrera;
    private String semestre;
    private double promedio;
    private String correo;
    private String institucion;
    private String sexo;
    private int telefono;
    private String direccion;
    /*Atributos privados, metodos publicos*/

    //constructor
    public Estudiante(String nombre,String apellido,int edad,
            String matricula,String carrera,String semestre,double promedio
            ,String correo,String institucion,String sexo,
            int telefono,String direccion) {
        this.nombre=nombre;
        this.apellido=apellido;
        this.edad=edad;
        this.matricula=matricula;
        this.carrera=carrera;
        this.semestre=semestre;
        this.promedio=promedio;
        this.correo=correo;
        this.institucion=institucion;
        this.sexo=sexo;
        this.telefono=telefono;
        this.direccion=direccion;
    }
    //metodos gets
    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public int getEdad() {
        return edad;
    }
    public String getMatricula() {
        return matricula;
    }
    public String getCarrera() {
        return carrera;
    }
    public String getSemestre() {
        return semestre;
    }
    public double getPromedio() {
        return promedio;
    }
    public String getCorreo() {
        return correo;
    }
    public String getInstitucion() {
        return institucion;
    }
    public String getSexo() {
        return sexo;
    }
    public int getTelefono() {
        return telefono;
    }
    public String getDireccion() {
        return direccion;
    }
    //Metodos Sets
    public void setNombre(String nombre) {
        this.nombre=nombre;
    }
    public void setEdad(int edad) {
        this.edad=edad;
    }
    //Muestra los datos
    public String toString() {
        return "Nombre: "+getNombre()+" "+getApellido()+
             "\nEdad: "+getEdad()+
             "\nMatricula: "+getMatricula()+
             "\nCarrera: "+getCarrera()+
             "\nSemestre: "+getSemestre()+
             "\nPromedio: "+getPromedio()+
             "\nCorreo: "+getCorreo()+
             "\nInstitucion: "+getInstitucion()+
             "\nSexo: "+getSexo()+
             "\nTelefono: "+getTelefono()+
             "\nDireccion: "+getDireccion();
    }
}
