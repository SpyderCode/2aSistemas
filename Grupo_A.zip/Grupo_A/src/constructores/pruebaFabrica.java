package constructores;

import javax.swing.JOptionPane;

public class pruebaFabrica {

    public static void main(String[] args) {
        Fabrica F1=new Fabrica("APOL","Zacatecas","computadoras 100% legit",
                492292999,5, "7:00 a 6:99","http://MarcaPatitoapple.com.mx.kr.eu",
                "apolpc@apol.com","NOAPPLE93123",800815);
        JOptionPane.showMessageDialog(null, F1.toString(),"APOL HEDCUARTER 100% LEGIT",JOptionPane.INFORMATION_MESSAGE);
        F1.setTelefono(499120123);
        F1.setDireccion("PASTEL 12");
        F1.setNombre("APPEL");
        JOptionPane.showMessageDialog(null, F1.toString(),"APOL HEDCUARTER 100% LEGIT",JOptionPane.INFORMATION_MESSAGE);
        

    }

}
